import * as i0 from '@angular/core';
import { OnInit, EventEmitter, InjectionToken, OnChanges, NgZone, SimpleChanges, AfterViewInit, ElementRef, TemplateRef, OnDestroy, PipeTransform } from '@angular/core';
import * as rxjs from 'rxjs';
import { Observable, Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpRef, GridState, PagedResult, LoadingService } from 'lib-servicios';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { NzResultStatusType } from 'ng-zorro-antd/result';
import { ControlValueAccessor, NgControl, FormControl } from '@angular/forms';
import { MatSelect } from '@angular/material/select';
import { MatDatepickerInput } from '@angular/material/datepicker';
import { MatDateFormats } from '@angular/material/core';
import { IMaskDirective } from 'angular-imask';
import { NzTableSortOrder } from 'ng-zorro-antd/table';
import { NzUploadFile, NzUploadListType, NzUploadChangeParam, NzUploadXHRArgs } from 'ng-zorro-antd/upload';

type DialogSize = 's' | 'm' | 'l' | 'xl' | 'full';
declare class BasicDialogComponent {
    title: string;
    size: DialogSize;
    height: string | null;
    width: string | null;
    centered: boolean;
    resolvedWidth: string;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BasicDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BasicDialogComponent, "app-basic-dialog", never, { "title": { "alias": "title"; "required": false; }; "size": { "alias": "size"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; "centered": { "alias": "centered"; "required": false; }; }, {}, never, ["[body]", "[leftFooter]", "[footer]"], true, never>;
}

interface Breadcrumb {
    label: string;
    url: string;
}
declare class BreadcrumbService {
    private router;
    private breadcrumbs$;
    constructor(router: Router);
    get breadcrumbs(): rxjs.Observable<Breadcrumb[]>;
    private createBreadcrumbs;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BreadcrumbService>;
}

declare class BreadcrumbComponent {
    private breadcrumbService;
    breadcrumbs$: rxjs.Observable<Breadcrumb[]>;
    constructor(breadcrumbService: BreadcrumbService);
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "app-breadcrumb", never, {}, {}, never, never, true, never>;
}

declare const ICONS: {
    readonly add: "add";
    readonly remove: "close";
    readonly edit: "edit";
    readonly delete: "delete";
    readonly save: "save";
    readonly view: "visibility";
    readonly search: "search";
    readonly filter: "filter_list";
    readonly sort: "sort";
    readonly home: "home";
    readonly back: "arrow_back";
    readonly next: "arrow_forward";
    readonly user: "person";
    readonly users: "groups";
    readonly employee: "badge";
    readonly company: "business";
    readonly warehouse: "warehouse";
    readonly inventory: "inventory";
    readonly truck: "local_shipping";
    readonly route: "route";
    readonly map: "map";
    readonly location: "location_on";
    readonly schedule: "schedule";
    readonly success: "check_circle";
    readonly error: "error";
    readonly warning: "warning";
    readonly info: "info";
    readonly phone: "phone";
    readonly email: "email";
    readonly notifications: "notifications";
    readonly settings: "settings";
    readonly advanced: "tune";
    readonly close: "close";
    readonly assignment_add: "assignment_add";
    readonly worker: "person_apron";
    readonly engineering: "engineering";
    readonly caja_herr: "home_repair_service";
    readonly dolar: "attach_money";
    readonly billete: "payments";
    readonly billetera: "wallet";
    readonly bank: "account_balance";
    readonly apps: "apps";
    readonly folder: "folder_copy";
    readonly download: "download";
};
type IconKey = keyof typeof ICONS;
type IconValue = typeof ICONS[IconKey];

interface ButtonProps {
    key: string;
    label: string;
    icon?: IconKey;
    type: 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark';
    disabled?: boolean;
    hidden?: boolean;
}

type ButtonType = 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark';

declare class ButtonComponent implements OnInit {
    ref: HttpRef;
    key: string;
    label: string;
    icon?: IconKey;
    type: ButtonType;
    disabled?: boolean;
    hidden?: boolean;
    props?: ButtonProps;
    ICONS: {
        readonly add: "add";
        readonly remove: "close";
        readonly edit: "edit";
        readonly delete: "delete";
        readonly save: "save";
        readonly view: "visibility";
        readonly search: "search";
        readonly filter: "filter_list";
        readonly sort: "sort";
        readonly home: "home";
        readonly back: "arrow_back";
        readonly next: "arrow_forward";
        readonly user: "person";
        readonly users: "groups";
        readonly employee: "badge";
        readonly company: "business";
        readonly warehouse: "warehouse";
        readonly inventory: "inventory";
        readonly truck: "local_shipping";
        readonly route: "route";
        readonly map: "map";
        readonly location: "location_on";
        readonly schedule: "schedule";
        readonly success: "check_circle";
        readonly error: "error";
        readonly warning: "warning";
        readonly info: "info";
        readonly phone: "phone";
        readonly email: "email";
        readonly notifications: "notifications";
        readonly settings: "settings";
        readonly advanced: "tune";
        readonly close: "close";
        readonly assignment_add: "assignment_add";
        readonly worker: "person_apron";
        readonly engineering: "engineering";
        readonly caja_herr: "home_repair_service";
        readonly dolar: "attach_money";
        readonly billete: "payments";
        readonly billetera: "wallet";
        readonly bank: "account_balance";
        readonly apps: "apps";
        readonly folder: "folder_copy";
        readonly download: "download";
    };
    types: Record<ButtonType, string>;
    onClick: EventEmitter<void>;
    ngOnInit(): void;
    click(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "app-button", never, { "ref": { "alias": "ref"; "required": false; }; "key": { "alias": "key"; "required": false; }; "label": { "alias": "label"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "type": { "alias": "type"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "hidden": { "alias": "hidden"; "required": false; }; "props": { "alias": "props"; "required": false; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}

declare class CoreViewComponent {
    title: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CoreViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CoreViewComponent, "app-core-view", never, { "title": { "alias": "title"; "required": false; }; }, {}, never, ["[header]", "[body]"], true, never>;
}

interface Cards {
    title: string;
    subtitle?: string;
    value?: string | number;
    href: string;
    icon: IconKey;
    iconBg?: string;
    iconColor?: string;
    trend?: string;
    trendUp?: boolean;
}
declare class DashboardComponent {
    private router;
    private route;
    cards: Cards[];
    ICONS: {
        readonly add: "add";
        readonly remove: "close";
        readonly edit: "edit";
        readonly delete: "delete";
        readonly save: "save";
        readonly view: "visibility";
        readonly search: "search";
        readonly filter: "filter_list";
        readonly sort: "sort";
        readonly home: "home";
        readonly back: "arrow_back";
        readonly next: "arrow_forward";
        readonly user: "person";
        readonly users: "groups";
        readonly employee: "badge";
        readonly company: "business";
        readonly warehouse: "warehouse";
        readonly inventory: "inventory";
        readonly truck: "local_shipping";
        readonly route: "route";
        readonly map: "map";
        readonly location: "location_on";
        readonly schedule: "schedule";
        readonly success: "check_circle";
        readonly error: "error";
        readonly warning: "warning";
        readonly info: "info";
        readonly phone: "phone";
        readonly email: "email";
        readonly notifications: "notifications";
        readonly settings: "settings";
        readonly advanced: "tune";
        readonly close: "close";
        readonly assignment_add: "assignment_add";
        readonly worker: "person_apron";
        readonly engineering: "engineering";
        readonly caja_herr: "home_repair_service";
        readonly dolar: "attach_money";
        readonly billete: "payments";
        readonly billetera: "wallet";
        readonly bank: "account_balance";
        readonly apps: "apps";
        readonly folder: "folder_copy";
        readonly download: "download";
    };
    constructor(router: Router, route: ActivatedRoute);
    onClick(href: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardComponent, "app-dashboard", never, { "cards": { "alias": "cards"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DashboardV2Component {
    private router;
    private route;
    cards: Cards[];
    ICONS: {
        readonly add: "add";
        readonly remove: "close";
        readonly edit: "edit";
        readonly delete: "delete";
        readonly save: "save";
        readonly view: "visibility";
        readonly search: "search";
        readonly filter: "filter_list";
        readonly sort: "sort";
        readonly home: "home";
        readonly back: "arrow_back";
        readonly next: "arrow_forward";
        readonly user: "person";
        readonly users: "groups";
        readonly employee: "badge";
        readonly company: "business";
        readonly warehouse: "warehouse";
        readonly inventory: "inventory";
        readonly truck: "local_shipping";
        readonly route: "route";
        readonly map: "map";
        readonly location: "location_on";
        readonly schedule: "schedule";
        readonly success: "check_circle";
        readonly error: "error";
        readonly warning: "warning";
        readonly info: "info";
        readonly phone: "phone";
        readonly email: "email";
        readonly notifications: "notifications";
        readonly settings: "settings";
        readonly advanced: "tune";
        readonly close: "close";
        readonly assignment_add: "assignment_add";
        readonly worker: "person_apron";
        readonly engineering: "engineering";
        readonly caja_herr: "home_repair_service";
        readonly dolar: "attach_money";
        readonly billete: "payments";
        readonly billetera: "wallet";
        readonly bank: "account_balance";
        readonly apps: "apps";
        readonly folder: "folder_copy";
        readonly download: "download";
    };
    constructor(router: Router, route: ActivatedRoute);
    onClick(href: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardV2Component, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardV2Component, "app-dashboard-v2", never, { "cards": { "alias": "cards"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AlertDialogComponent {
    private dialogRef;
    type: NzResultStatusType;
    title: string;
    subtitle?: string;
    constructor(dialogRef: MatDialogRef<AlertDialogComponent>, data: {
        type: NzResultStatusType;
        title: string;
        subtitle?: string;
    });
    onSalir(b: boolean): void;
    onAceptar(b: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertDialogComponent, "app-dialog-alert", never, {}, {}, never, never, true, never>;
}

declare class FilterComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterComponent, "app-filter", never, {}, {}, never, ["[body]", "[footer]"], true, never>;
}

interface ComboType$1 {
    numero: string | number;
    descripcion: string;
}

interface IComboDataProvider {
    getDataCombo(type: string, extraParams?: any): Observable<ComboType$1[]>;
}
declare const COMBO_DATA_PROVIDER: InjectionToken<IComboDataProvider>;

declare class ComboComponent implements ControlValueAccessor, OnInit, OnChanges {
    private dataProvider;
    private zone;
    ngControl: NgControl;
    matSelect: MatSelect;
    label: string;
    type: string;
    isLocal: boolean;
    data: ComboType$1[];
    readonly: boolean;
    extraParams: any;
    data$: Observable<ComboType$1[]>;
    value: string | number | null;
    disabled: boolean;
    loaded: boolean;
    private loading;
    private onChange;
    private onTouched;
    constructor(dataProvider: IComboDataProvider, zone: NgZone, ngControl: NgControl);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private loadData;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onSelectionChange(value: any): void;
    handleClick(): void;
    clear(): void;
    trackByNumero: (_: number, item: ComboType$1) => string | number;
    compareByNumero: (a: any, b: any) => boolean;
    getDescripcion(items: ComboType$1[] | null): string;
    get control(): FormControl;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComboComponent, [null, null, { optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ComboComponent, "app-combo", never, { "label": { "alias": "label"; "required": true; }; "type": { "alias": "type"; "required": false; }; "isLocal": { "alias": "isLocal"; "required": false; }; "data": { "alias": "data"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "extraParams": { "alias": "extraParams"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DateFormFieldComponent implements ControlValueAccessor {
    ngControl: NgControl;
    datepickerInput: MatDatepickerInput<Date>;
    label: string;
    readonly: boolean;
    value: Date | null;
    disabled: boolean;
    onChange: (_: Date | null) => void;
    onTouched: () => void;
    constructor(ngControl: NgControl);
    writeValue(value: Date | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onDateChange(date: Date | null): void;
    clear(): void;
    get control(): FormControl;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateFormFieldComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateFormFieldComponent, "app-date-form-field", never, { "label": { "alias": "label"; "required": true; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, true, never>;
}

declare const APP_DATE_FORMATS: MatDateFormats;

declare class DecimalFormFieldComponent implements ControlValueAccessor, OnInit, AfterViewInit {
    ngControl: NgControl;
    inputRef: ElementRef<HTMLInputElement>;
    label: string;
    readonly: boolean;
    disabled: boolean;
    decimals: number;
    value: number | null;
    private maskRef;
    private onChange;
    private onTouched;
    maskOptions: any;
    constructor(ngControl: NgControl);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    onAccept(e: string): void;
    writeValue(value: number | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    clear(): void;
    handleBlur(): void;
    get control(): FormControl | null;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<DecimalFormFieldComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DecimalFormFieldComponent, "app-decimal-form-field", never, { "label": { "alias": "label"; "required": true; }; "readonly": { "alias": "readonly"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "decimals": { "alias": "decimals"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FormFieldComponent implements ControlValueAccessor {
    ngControl: NgControl;
    label: string;
    readonly: boolean;
    inputRef: ElementRef<HTMLInputElement>;
    value: string | null;
    disabled: boolean;
    private onChange;
    private onTouched;
    constructor(ngControl: NgControl);
    writeValue(value: string | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onInput(value: string): void;
    onBlur(): void;
    clear(): void;
    get control(): FormControl;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormFieldComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormFieldComponent, "app-form-field", never, { "label": { "alias": "label"; "required": true; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, true, never>;
}

declare class NumberFormFieldComponent implements ControlValueAccessor {
    ngControl: NgControl;
    label: string;
    readonly: boolean;
    inputRef: ElementRef<HTMLInputElement>;
    value: number | null;
    disabled: boolean;
    private onChange;
    private onTouched;
    constructor(ngControl: NgControl);
    writeValue(value: number | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onInput(raw: string): void;
    onBlur(): void;
    clear(): void;
    private format;
    get control(): FormControl;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumberFormFieldComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NumberFormFieldComponent, "app-number-form-field", never, { "label": { "alias": "label"; "required": true; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TextareaFormFieldComponent implements ControlValueAccessor {
    ngControl: NgControl;
    label: string;
    readonly: boolean;
    textareaRef: ElementRef<HTMLTextAreaElement>;
    value: string | null;
    disabled: boolean;
    private onChange;
    private onTouched;
    constructor(ngControl: NgControl);
    writeValue(value: string | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onInput(value: string): void;
    onBlur(): void;
    clear(): void;
    get control(): FormControl;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaFormFieldComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextareaFormFieldComponent, "app-textarea-form-field", never, { "label": { "alias": "label"; "required": true; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ViajeMaskComponent implements ControlValueAccessor, AfterViewInit {
    ngControl: NgControl;
    label: string;
    readonly: boolean;
    inputRef: ElementRef<HTMLInputElement>;
    value: string | null;
    disabled: boolean;
    private maskRef;
    private onChange;
    private onTouched;
    constructor(ngControl: NgControl);
    ngAfterViewInit(): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    clear(): void;
    get control(): FormControl;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViajeMaskComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViajeMaskComponent, "app-viaje-mask", never, { "label": { "alias": "label"; "required": true; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, true, never>;
}

interface ComboType {
    numero: string | number;
    descripcion: string;
}

declare class MultipleComboComponent implements ControlValueAccessor, OnInit, OnChanges {
    private dataProvider;
    ngControl: NgControl;
    matSelect: MatSelect;
    label: string;
    type: string;
    isLocal: boolean;
    data: ComboType[];
    readonly: boolean;
    extraParams: any;
    data$: Observable<ComboType[]>;
    value: (string | number)[];
    disabled: boolean;
    search: string;
    filteredData$: Observable<ComboType[]>;
    private pendingValue;
    private onChange;
    private onTouched;
    constructor(dataProvider: IComboDataProvider, ngControl: NgControl);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private loadData;
    writeValue(value: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onSelectionChange(value: any): void;
    clear(): void;
    trackByNumero: (_: number, item: ComboType) => string | number;
    compareByNumero: (a: any, b: any) => boolean;
    onSearchChange(value: string): void;
    getDescripcion(items: ComboType[] | null): string;
    get control(): FormControl;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultipleComboComponent, [null, { optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultipleComboComponent, "app-multiple-combo", never, { "label": { "alias": "label"; "required": true; }; "type": { "alias": "type"; "required": false; }; "isLocal": { "alias": "isLocal"; "required": false; }; "data": { "alias": "data"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "extraParams": { "alias": "extraParams"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CuitMaskComponent implements ControlValueAccessor {
    ngControl: NgControl;
    imask: IMaskDirective<any>;
    label: string;
    readonly: boolean;
    inputRef: ElementRef<HTMLInputElement>;
    value: string | null;
    disabled: boolean;
    mask: {
        mask: string;
        lazy: boolean;
    };
    private onChange;
    private onTouched;
    constructor(ngControl: NgControl);
    writeValue(value: string | number | null): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    onAccept(masked: string): void;
    onBlur(): void;
    clear(): void;
    private validarCUIT;
    get control(): FormControl;
    get showError(): boolean;
    get errorMessage(): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<CuitMaskComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CuitMaskComponent, "app-cuit-mask", never, { "label": { "alias": "label"; "required": true; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, true, never>;
}

interface GridConfig<T> {
    columns: GridColumn<T>[];
    menuActions?: GridMenuAction<T>[];
    toolBarActions?: GridToolBarAction<T>[];
    selectableSettings?: SelectebleSettings<T>;
    isEditable?: boolean;
}
declare class GridColumn<T> {
    key: keyof T;
    title: string;
    type: 'text' | 'numeric' | 'date' | 'template';
    format?: '{0:0}' | '{0:1}' | '{0:2}' | 'cuit' | 'ddMMyyyy hh:MM:ss' | 'ddMMyyyy hh:MM' | 'ddMMyyyy' | 'ddMMyy' | 'ddMM';
    filter?: boolean;
    hidden?: boolean;
    sortable?: boolean;
    editable?: boolean;
    template?: TemplateRef<any>;
    editTemplate?: TemplateRef<any>;
}
declare class GridMenuAction<T> {
    key: string;
    label: string;
    icon?: IconKey;
    hidden?: (row: T) => boolean;
    disabled?: (row: T) => boolean;
    onClick: (row: T) => void;
}
declare class GridToolBarAction<T> {
    key: string;
    label: string;
    icon?: IconKey;
    type: 'primary' | 'secondary' | 'success' | 'danger' | 'warning' | 'info' | 'light' | 'dark';
    hidden?: boolean;
    disabledOnEmptyRows?: boolean;
    disabled?: (rows: T[]) => boolean;
    onClick: (rows: T[]) => void;
    position?: 'left' | 'right';
}
declare class SelectebleSettings<T> {
    type: 'multiple' | 'single';
    selectable: boolean;
    esSelectable?: (row: T) => boolean;
}

declare abstract class BaseGridService<T> {
    private dataSub$;
    private totalSub$;
    ref: HttpRef;
    data$: Observable<T[]>;
    total$: Observable<number>;
    state: GridState;
    protected setData(data: T[], total: number): void;
    search(): void;
    abstract getData(state: GridState, ref?: HttpRef): Observable<PagedResult<T>>;
    setSort(field: string, direction: 'asc' | 'desc' | null): void;
    setFilter(field: string, value: any): void;
}

declare class AlertService {
    private dialog;
    constructor(dialog: MatDialog);
    error$(title: string, subtitle?: string): Observable<boolean>;
    success$(title: string, subtitle?: string): Observable<boolean>;
    info$(title: string, subtitle?: string): Observable<boolean>;
    warning$(title: string, subtitle?: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AlertService>;
}

type InternalItem<T> = {
    __uuid: string;
    data: T;
};
declare const uuid: () => string;

declare abstract class LocalGridService<T extends Record<string, any>> extends BaseGridService<T> {
    protected items: InternalItem<T>[];
    constructor(initialData?: InternalItem<T>[]);
    protected wrap(data: T): InternalItem<T>;
    protected unwrap(items: InternalItem<T>[]): T[];
    getData(state: GridState): Observable<PagedResult<T>>;
    add(item: T): void;
    remove(item: T): void;
    update(item: T): void;
    setAll(data: T[]): void;
    clear(): void;
    private findId;
}

interface IEditableGridService<T> {
    add(item: T): void;
    update(item: T): void;
    remove(item: T): void;
    getRowKey(row: T): string;
    alertService: AlertService;
}
declare class EditableGridService<T extends Record<string, any>> extends LocalGridService<T> implements IEditableGridService<T> {
    alertService: AlertService;
    constructor(alertService: AlertService);
    getRowKey(row: T): string;
}

declare class GridComponent<T extends Record<string, any>> implements OnInit, OnDestroy {
    dataService: BaseGridService<T>;
    config: GridConfig<T>;
    hiddenRefresh: boolean;
    isLocal: boolean;
    ref: HttpRef;
    data: T[];
    columns: GridColumn<T>[];
    menuActions: GridMenuAction<T>[];
    toolbarButtons: GridToolBarAction<T>[];
    selectableSettings?: SelectebleSettings<T>;
    checked: boolean;
    indeterminate: boolean;
    total: number;
    ICONS: {
        readonly add: "add";
        readonly remove: "close";
        readonly edit: "edit";
        readonly delete: "delete";
        readonly save: "save";
        readonly view: "visibility";
        readonly search: "search";
        readonly filter: "filter_list";
        readonly sort: "sort";
        readonly home: "home";
        readonly back: "arrow_back";
        readonly next: "arrow_forward";
        readonly user: "person";
        readonly users: "groups";
        readonly employee: "badge";
        readonly company: "business";
        readonly warehouse: "warehouse";
        readonly inventory: "inventory";
        readonly truck: "local_shipping";
        readonly route: "route";
        readonly map: "map";
        readonly location: "location_on";
        readonly schedule: "schedule";
        readonly success: "check_circle";
        readonly error: "error";
        readonly warning: "warning";
        readonly info: "info";
        readonly phone: "phone";
        readonly email: "email";
        readonly notifications: "notifications";
        readonly settings: "settings";
        readonly advanced: "tune";
        readonly close: "close";
        readonly assignment_add: "assignment_add";
        readonly worker: "person_apron";
        readonly engineering: "engineering";
        readonly caja_herr: "home_repair_service";
        readonly dolar: "attach_money";
        readonly billete: "payments";
        readonly billetera: "wallet";
        readonly bank: "account_balance";
        readonly apps: "apps";
        readonly folder: "folder_copy";
        readonly download: "download";
    };
    activeFilterColumn?: string;
    searchValue: FormControl<string | null>;
    filterVisible: Record<string, boolean>;
    editableService?: EditableGridService<T>;
    selectedRows: T[];
    selectedRowsChange: EventEmitter<T[]>;
    private selectedSet;
    private destroy$;
    ngOnInit(): void;
    ngOnDestroy(): void;
    onPageSizeChange(): void;
    private buildConfgColumns;
    private defaultSelectable;
    isChecked(row: T): boolean;
    onRowChecked(row: T, checked: boolean): void;
    onAllChecked(checked: boolean): void;
    private refreshSelectionStatus;
    private resetSelectionStatus;
    isRowSelectable(row: T): boolean;
    get leftButtons(): GridToolBarAction<T>[];
    get rightButtons(): GridToolBarAction<T>[];
    hasFilter(key: keyof T): boolean;
    onFilterVisibleChange(visible: boolean, column: GridColumn<T>): void;
    applyFilter(field: string): void;
    resetFilter(field: string): void;
    getSortOrder(key: keyof T): NzTableSortOrder;
    onSort(key: keyof T, order: NzTableSortOrder): void;
    trackRow: (index: number, row: T) => string;
    private isEditableService;
    editCache: Record<string, {
        edit: boolean;
        data: T;
    }>;
    editingId?: string;
    private buildEditCache;
    startEdit(row: T): void;
    cancelEdit(row: T): void;
    addRow(): void;
    saveEdit(row: T): void;
    removeEdit(row: T): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GridComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GridComponent<any>, "app-grid", never, { "dataService": { "alias": "dataService"; "required": true; }; "config": { "alias": "config"; "required": true; }; "hiddenRefresh": { "alias": "hiddenRefresh"; "required": false; }; "isLocal": { "alias": "isLocal"; "required": false; }; "ref": { "alias": "ref"; "required": false; }; "selectedRows": { "alias": "selectedRows"; "required": false; }; }, { "selectedRowsChange": "selectedRowsChange"; }, never, never, true, never>;
}

declare class DynamicFormatPipe implements PipeTransform {
    private locale;
    private decimalPipe;
    private datePipe;
    transform(value: any, type: string, format?: string): any;
    private formatNumber;
    private formatDate;
    private formatCuit;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicFormatPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DynamicFormatPipe, "dynamicFormat", true>;
}

declare class GlobalSpinnerComponent {
    loadingService: LoadingService;
    constructor(loadingService: LoadingService);
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GlobalSpinnerComponent, "app-global-spinner", never, {}, {}, never, never, true, never>;
}

declare class FadeInComponent {
    speed: 'normal' | 'fast';
    static ɵfac: i0.ɵɵFactoryDeclaration<FadeInComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FadeInComponent, "app-fade-in", never, { "speed": { "alias": "speed"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/**
 * Servicio base para el UploadFilesComponent.
 *
 * Implementalo para conectar el componente con la API que quieras.
 * El componente no sabe nada de tu backend: solo llama a estos metodos.
 *
 * - `upload`   (obligatorio): sube un archivo y devuelve la respuesta.
 * - `list`     (opcional): devuelve los archivos ya cargados para mostrarlos al iniciar.
 * - `download` (opcional): descarga un archivo ya cargado.
 * - `remove`   (opcional): elimina un archivo del servidor.
 */
declare abstract class BaseUploadService {
    /** Sube un archivo y devuelve la respuesta del servidor. */
    abstract upload(file: File): Observable<void>;
    /** (Opcional) Devuelve los archivos ya cargados para mostrarlos al iniciar. */
    list?: () => Observable<NzUploadFile[]>;
    /** (Opcional) Descarga un archivo ya cargado. */
    download?: (file: NzUploadFile) => Observable<Blob>;
    /** (Opcional) Elimina un archivo del servidor. */
    remove?: (file: NzUploadFile) => Observable<any>;
}

/**
 * Componente generico para subir archivos.
 *
 * Se maneja con un `BaseUploadService` que le pasas por `[service]`.
 * El servicio decide contra que API pega. Ejemplo de uso:
 *
 * ```html
 * <app-upload-files [service]="miUploadService"></app-upload-files>
 * ```
 */
declare class UploadFilesComponent implements OnInit {
    /** Servicio que resuelve las operaciones contra la API. */
    service: BaseUploadService;
    /** Permite seleccionar varios archivos a la vez. */
    multiple: boolean;
    /** Tipos aceptados (ej: '.pdf,.png,image/*'). */
    accept?: string;
    /** Estilo de la lista: 'text' | 'picture' | 'picture-card'. */
    listType: NzUploadListType;
    /** Tamanio maximo por archivo en KB (0 = sin limite). */
    maxSizeKb: number;
    /** Deshabilita el componente. */
    disabled: boolean;
    /** Texto del boton disparador. */
    buttonText: string;
    /** Si el servicio implementa `list`, carga los archivos existentes al iniciar. */
    loadExisting: boolean;
    /** Lista de archivos (soporta two-way binding). */
    fileList: NzUploadFile[];
    fileListChange: EventEmitter<NzUploadFile[]>;
    /** Se emite cuando un archivo termina de subirse. */
    uploaded: EventEmitter<NzUploadFile>;
    /** Se emite cuando un archivo se elimina. */
    removed: EventEmitter<NzUploadFile>;
    /** Se emite en cada cambio de estado (ver ejemplo nzChange). */
    changed: EventEmitter<NzUploadChangeParam>;
    ngOnInit(): void;
    get showDownload(): boolean;
    /** Valida el tamanio antes de aceptar el archivo. */
    beforeUpload: (file: NzUploadFile) => boolean;
    /** Delega la subida de cada archivo al servicio inyectado. */
    customRequest: (item: NzUploadXHRArgs) => Subscription;
    /** Descarga usando el servicio (si lo implementa). */
    onDownload: (file: NzUploadFile) => void;
    /**
     * Elimina usando el servicio (si lo implementa).
     * Si el servicio no tiene `remove`, solo lo saca de la lista local.
     */
    onRemove: (file: NzUploadFile) => boolean | Observable<boolean>;
    /** Maneja los cambios de estado del upload (uploading | done | error | removed). */
    onChange(event: NzUploadChangeParam): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UploadFilesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UploadFilesComponent, "app-upload-files", never, { "service": { "alias": "service"; "required": true; }; "multiple": { "alias": "multiple"; "required": false; }; "accept": { "alias": "accept"; "required": false; }; "listType": { "alias": "listType"; "required": false; }; "maxSizeKb": { "alias": "maxSizeKb"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "buttonText": { "alias": "buttonText"; "required": false; }; "loadExisting": { "alias": "loadExisting"; "required": false; }; "fileList": { "alias": "fileList"; "required": false; }; }, { "fileListChange": "fileListChange"; "uploaded": "uploaded"; "removed": "removed"; "changed": "changed"; }, never, never, true, never>;
}

export { APP_DATE_FORMATS, AlertDialogComponent, AlertService, BaseGridService, BaseUploadService, BasicDialogComponent, BreadcrumbComponent, ButtonComponent, COMBO_DATA_PROVIDER, ComboComponent, CoreViewComponent, CuitMaskComponent, DashboardComponent, DashboardV2Component, DateFormFieldComponent, DecimalFormFieldComponent, DynamicFormatPipe, EditableGridService, FadeInComponent, FilterComponent, FormFieldComponent, GlobalSpinnerComponent, GridColumn, GridComponent, GridMenuAction, GridToolBarAction, ICONS, LocalGridService, MultipleComboComponent, NumberFormFieldComponent, SelectebleSettings, TextareaFormFieldComponent, UploadFilesComponent, ViajeMaskComponent, uuid };
export type { ButtonType, Cards, ComboType$1 as ComboType, GridConfig, IComboDataProvider, IEditableGridService, IconKey, IconValue, InternalItem };
