import * as i2 from '@angular/common';
import { NgStyle, CommonModule, NgClass, DecimalPipe, DatePipe, NgTemplateOutlet, AsyncPipe } from '@angular/common';
import * as i0 from '@angular/core';
import { Input, Component, Injectable, EventEmitter, Output, Inject, InjectionToken, forwardRef, ViewChild, Self, Optional, inject, LOCALE_ID, Pipe } from '@angular/core';
import * as i1 from '@angular/material/dialog';
import { MatDialogModule, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as i1$1 from '@angular/router';
import { NavigationEnd, RouterLink } from '@angular/router';
import { filter } from 'rxjs/operators';
import { BehaviorSubject, of, take, map, Subject, takeUntil } from 'rxjs';
import * as i4 from '@angular/material/icon';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import * as i2$1 from 'ng-zorro-antd/button';
import { NzButtonModule } from 'ng-zorro-antd/button';
import * as i3$2 from 'ng-zorro-antd/icon';
import { NzIconModule, provideNzIconsPatch } from 'ng-zorro-antd/icon';
import * as i5 from 'ng-zorro-antd/result';
import { NzResultModule } from 'ng-zorro-antd/result';
import { NzTypographyModule } from 'ng-zorro-antd/typography';
import * as i3 from 'ng-zorro-antd/core/transition-patch';
import * as i4$1 from 'ng-zorro-antd/core/wave';
import * as i1$2 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import * as i1$3 from '@angular/forms';
import { NG_VALUE_ACCESSOR, FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import * as i5$1 from '@angular/material/datepicker';
import { MatDatepickerModule, MatDatepickerInput } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i3$1 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i2$2 from '@angular/material/select';
import { MatSelectModule, MatSelect } from '@angular/material/select';
import * as i5$2 from 'angular-imask';
import { IMaskModule, IMaskDirective } from 'angular-imask';
import IMask from 'imask';
import * as i1$4 from 'ng-zorro-antd/table';
import { NzTableModule } from 'ng-zorro-antd/table';
import * as i2$3 from 'ng-zorro-antd/dropdown';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import * as i8 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import { NzFloatButtonModule } from 'ng-zorro-antd/float-button';
import * as i1$5 from 'lib-servicios';
import * as i1$6 from 'ng-zorro-antd/upload';
import { NzUploadModule } from 'ng-zorro-antd/upload';
import { PaperClipOutline, DeleteOutline, DownloadOutline, LoadingOutline, UploadOutline, EyeOutline, PlusOutline } from '@ant-design/icons-angular/icons';

class BasicDialogComponent {
    title = '';
    size = 'm';
    height = null;
    width = null;
    centered = true;
    resolvedWidth = '600px';
    ngOnInit() {
        if (this.width) {
            this.resolvedWidth = this.width;
            return;
        }
        const map = {
            s: '400px',
            m: '600px',
            l: '800px',
            xl: '1100px',
            full: '95vw',
        };
        this.resolvedWidth = map[this.size];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BasicDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: BasicDialogComponent, isStandalone: true, selector: "app-basic-dialog", inputs: { title: "title", size: "size", height: "height", width: "width", centered: "centered" }, ngImport: i0, template: "<div\n  class=\"dialog-wrapper\"\n  [ngStyle]=\"{width: resolvedWidth, height: height}\"\n>\n  <!-- HEADER -->\n   @if (title) {\n    <h2 mat-dialog-title>\n        {{ title }}\n    </h2>\n   }\n  \n  <!-- BODY -->\n  <mat-dialog-content class=\"dialog-body\">\n    <ng-content select=\"[body]\"></ng-content>\n  </mat-dialog-content>\n\n  <!-- FOOTER -->\n  <mat-dialog-actions class=\"dialog-footer\">\n    <div class=\"left\">\n      <ng-content select=\"[leftFooter]\"></ng-content>\n    </div>\n\n    <div class=\"right\">\n      <ng-content select=\"[footer]\"></ng-content>\n    </div>\n  </mat-dialog-actions>\n</div>", styles: [".dialog-wrapper{max-width:95vw;display:flex;flex-direction:column}.dialog-body{max-height:65vh;overflow:auto;padding-top:8px}.dialog-footer{display:flex;width:100%;padding-top:12px}.dialog-footer .left{margin-right:auto;align-items:center;justify-content:center}.dialog-footer .right{margin-left:auto;display:flex;align-items:center;justify-content:center;gap:8px}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BasicDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-basic-dialog', imports: [MatDialogModule, NgStyle], template: "<div\n  class=\"dialog-wrapper\"\n  [ngStyle]=\"{width: resolvedWidth, height: height}\"\n>\n  <!-- HEADER -->\n   @if (title) {\n    <h2 mat-dialog-title>\n        {{ title }}\n    </h2>\n   }\n  \n  <!-- BODY -->\n  <mat-dialog-content class=\"dialog-body\">\n    <ng-content select=\"[body]\"></ng-content>\n  </mat-dialog-content>\n\n  <!-- FOOTER -->\n  <mat-dialog-actions class=\"dialog-footer\">\n    <div class=\"left\">\n      <ng-content select=\"[leftFooter]\"></ng-content>\n    </div>\n\n    <div class=\"right\">\n      <ng-content select=\"[footer]\"></ng-content>\n    </div>\n  </mat-dialog-actions>\n</div>", styles: [".dialog-wrapper{max-width:95vw;display:flex;flex-direction:column}.dialog-body{max-height:65vh;overflow:auto;padding-top:8px}.dialog-footer{display:flex;width:100%;padding-top:12px}.dialog-footer .left{margin-right:auto;align-items:center;justify-content:center}.dialog-footer .right{margin-left:auto;display:flex;align-items:center;justify-content:center;gap:8px}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], size: [{
                type: Input
            }], height: [{
                type: Input
            }], width: [{
                type: Input
            }], centered: [{
                type: Input
            }] } });

// breadcrumb.service.ts
class BreadcrumbService {
    router;
    breadcrumbs$ = new BehaviorSubject([]);
    constructor(router) {
        this.router = router;
        this.router.events
            .pipe(filter(event => event instanceof NavigationEnd))
            .subscribe(() => {
            const root = this.router.routerState.snapshot.root;
            const breadcrumbs = this.createBreadcrumbs(root);
            this.breadcrumbs$.next(breadcrumbs);
        });
    }
    get breadcrumbs() {
        return this.breadcrumbs$.asObservable();
    }
    createBreadcrumbs(route, url = '', breadcrumbs = []) {
        const routeUrl = route.url.map(segment => segment.path).join('/');
        if (routeUrl) {
            url += `/${routeUrl}`;
        }
        const label = route.data['title'];
        if (label) {
            breadcrumbs.push({ label, url });
        }
        route.children.forEach(child => this.createBreadcrumbs(child, url, breadcrumbs));
        return breadcrumbs;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BreadcrumbService, deps: [{ token: i1$1.Router }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BreadcrumbService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BreadcrumbService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.Router }] });

class BreadcrumbComponent {
    breadcrumbService;
    breadcrumbs$;
    constructor(breadcrumbService) {
        this.breadcrumbService = breadcrumbService;
        this.breadcrumbs$ = this.breadcrumbService.breadcrumbs;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BreadcrumbComponent, deps: [{ token: BreadcrumbService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: BreadcrumbComponent, isStandalone: true, selector: "app-breadcrumb", ngImport: i0, template: "<nav aria-label=\"breadcrumb\">\n  <ol class=\"breadcrumb\">\n    <li\n      class=\"breadcrumb-item\"\n      *ngFor=\"let crumb of breadcrumbs$ | async; let last = last\"\n      [class.active]=\"last\"\n    >\n      <a *ngIf=\"!last\" [routerLink]=\"crumb.url\">\n        {{ crumb.label }}\n      </a>\n      <span *ngIf=\"last\">\n        {{ crumb.label }}\n      </span>\n    </li>\n  </ol>\n</nav>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-breadcrumb', standalone: true, imports: [CommonModule, RouterLink], template: "<nav aria-label=\"breadcrumb\">\n  <ol class=\"breadcrumb\">\n    <li\n      class=\"breadcrumb-item\"\n      *ngFor=\"let crumb of breadcrumbs$ | async; let last = last\"\n      [class.active]=\"last\"\n    >\n      <a *ngIf=\"!last\" [routerLink]=\"crumb.url\">\n        {{ crumb.label }}\n      </a>\n      <span *ngIf=\"last\">\n        {{ crumb.label }}\n      </span>\n    </li>\n  </ol>\n</nav>\n" }]
        }], ctorParameters: () => [{ type: BreadcrumbService }] });

const ICONS = {
    // acciones básicas
    add: 'add',
    remove: 'close',
    edit: 'edit',
    delete: 'delete',
    save: 'save',
    view: 'visibility',
    // búsqueda
    search: 'search',
    filter: 'filter_list',
    sort: 'sort',
    // navegación
    home: 'home',
    back: 'arrow_back',
    next: 'arrow_forward',
    // usuarios
    user: 'person',
    users: 'groups',
    employee: 'badge',
    // empresa
    company: 'business',
    warehouse: 'warehouse',
    inventory: 'inventory',
    // logística
    truck: 'local_shipping',
    route: 'route',
    map: 'map',
    location: 'location_on',
    schedule: 'schedule',
    // estados
    success: 'check_circle',
    error: 'error',
    warning: 'warning',
    info: 'info',
    // comunicación
    phone: 'phone',
    email: 'email',
    notifications: 'notifications',
    // sistema
    settings: 'settings',
    advanced: 'tune',
    close: 'close',
    assignment_add: 'assignment_add',
    worker: 'person_apron',
    engineering: 'engineering',
    caja_herr: 'home_repair_service',
    dolar: 'attach_money',
    billete: 'payments',
    billetera: 'wallet',
    bank: 'account_balance',
    apps: 'apps',
    folder: 'folder_copy',
    download: 'download'
};

class ButtonComponent {
    ref = { loading: false };
    key;
    label;
    icon;
    type = 'primary';
    disabled = false;
    hidden = false;
    props;
    ICONS = ICONS;
    types = {
        primary: 'btn btn-primary',
        secondary: 'btn btn-secondary',
        success: 'btn btn-success',
        danger: 'btn btn-danger',
        warning: 'btn btn-warning',
        info: 'btn btn-info',
        light: 'btn btn-light btn-borde-negro',
        dark: 'btn btn-dark',
    };
    onClick = new EventEmitter();
    ngOnInit() {
        if (this.props) {
            this.key = this.props.key;
            this.label = this.props.label;
            this.icon = this.props.icon;
            this.type = this.props.type;
            this.disabled = this.props.disabled;
            this.hidden = this.props.hidden;
        }
    }
    click() {
        this.onClick.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: ButtonComponent, isStandalone: true, selector: "app-button", inputs: { ref: "ref", key: "key", label: "label", icon: "icon", type: "type", disabled: "disabled", hidden: "hidden", props: "props" }, outputs: { onClick: "onClick" }, ngImport: i0, template: "<button\n  type=\"button\"\n  [ngClass]=\"types[type]\"\n  [disabled]=\"disabled || ref.loading\"\n  [hidden]=\"hidden\"\n  (click)=\"click()\"\n>\n  @if (icon) {\n    <mat-icon>{{ ICONS[icon] }}</mat-icon>\n  }\n  {{ label }}\n</button>\n", styles: [".btn{display:flex;align-items:center;justify-content:center;gap:10px}.btn-borde-negro{border-color:#000}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ButtonComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-button', imports: [NgClass, MatIcon], template: "<button\n  type=\"button\"\n  [ngClass]=\"types[type]\"\n  [disabled]=\"disabled || ref.loading\"\n  [hidden]=\"hidden\"\n  (click)=\"click()\"\n>\n  @if (icon) {\n    <mat-icon>{{ ICONS[icon] }}</mat-icon>\n  }\n  {{ label }}\n</button>\n", styles: [".btn{display:flex;align-items:center;justify-content:center;gap:10px}.btn-borde-negro{border-color:#000}\n"] }]
        }], propDecorators: { ref: [{
                type: Input
            }], key: [{
                type: Input
            }], label: [{
                type: Input
            }], icon: [{
                type: Input
            }], type: [{
                type: Input
            }], disabled: [{
                type: Input
            }], hidden: [{
                type: Input
            }], props: [{
                type: Input
            }], onClick: [{
                type: Output
            }] } });

class CoreViewComponent {
    title;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CoreViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: CoreViewComponent, isStandalone: true, selector: "app-core-view", inputs: { title: "title" }, ngImport: i0, template: "<div class=\"core-card\">\n  <div class=\"core-card-header\">\n    @if (title) {\n      <h2>{{ title }}</h2>\n    }\n    <ng-content select=\"[header]\"></ng-content>\n  </div>\n\n  <div class=\"core-card-body\">\n    <ng-content select=\"[body]\"></ng-content>\n  </div>\n</div>", styles: [".core-card{background:#fff;border-radius:12px;box-shadow:0 8px 24px #00000014;padding:0;overflow:hidden}.core-card-header{padding:16px 20px;border-bottom:1px solid #eee;background:#fafafa;display:flex;flex-direction:column;gap:12px}.core-card-header h2{margin:0;font-size:1rem;font-weight:600;color:#333}.core-card-body{padding:20px;color:#444;font-size:.95rem}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CoreViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-core-view', template: "<div class=\"core-card\">\n  <div class=\"core-card-header\">\n    @if (title) {\n      <h2>{{ title }}</h2>\n    }\n    <ng-content select=\"[header]\"></ng-content>\n  </div>\n\n  <div class=\"core-card-body\">\n    <ng-content select=\"[body]\"></ng-content>\n  </div>\n</div>", styles: [".core-card{background:#fff;border-radius:12px;box-shadow:0 8px 24px #00000014;padding:0;overflow:hidden}.core-card-header{padding:16px 20px;border-bottom:1px solid #eee;background:#fafafa;display:flex;flex-direction:column;gap:12px}.core-card-header h2{margin:0;font-size:1rem;font-weight:600;color:#333}.core-card-body{padding:20px;color:#444;font-size:.95rem}\n"] }]
        }], propDecorators: { title: [{
                type: Input,
                args: ['title']
            }] } });

class DashboardComponent {
    router;
    route;
    cards = [];
    ICONS = ICONS;
    constructor(router, route) {
        this.router = router;
        this.route = route;
    }
    onClick(href) {
        this.router.navigate([href], { relativeTo: this.route });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DashboardComponent, deps: [{ token: i1$1.Router }, { token: i1$1.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: DashboardComponent, isStandalone: true, selector: "app-dashboard", inputs: { cards: "cards" }, ngImport: i0, template: "<div class=\"container-fluid\">\n  <div class=\"row g-4\">\n    @for (card of cards; track $index) {\n      <div class=\"col-xl-3 col-lg-4 col-md-6 col-sm-12\">\n        <a (click)=\"onClick(card.href)\" class=\"text-decoration-none\">\n          <div class=\"card stats-card h-100\">\n            <!-- icon -->\n            <div class=\"stats-top\">\n              <div\n                class=\"stats-icon\"\n                [style.background]=\"\n                  card.iconBg || 'linear-gradient(135deg,#3b82f6,#2563eb)'\n                \"\n                [style.color]=\"card.iconColor || 'white'\"\n              >\n                <mat-icon class=\"stats-icon-size\">{{\n                  ICONS[card.icon]\n                }}</mat-icon>\n              </div>\n              <div class=\"stats-text\">\n                <div class=\"stats-title\">{{ card.title }}</div>\n                @if (card.subtitle) {\n                  <div class=\"stats-sub\">{{ card.subtitle }}</div>\n                }\n              </div>\n            </div>\n          </div>\n\n          <div class=\"stats-bottom\">\n            <div class=\"stats-value\">{{ card.value }}</div>\n\n            @if (card.trend) {\n              <div\n                class=\"stats-trend\"\n                [class.up]=\"card.trendUp\"\n                [class.down]=\"card.trendUp === false\"\n              >\n                {{ card.trend }}\n              </div>\n            }\n          </div>\n        </a>\n      </div>\n    }\n  </div>\n</div>\n", styles: [".stats-card{border:none;border-radius:18px;background:#fff;transition:all .25s ease;box-shadow:0 8px 24px #0000000f;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}.stats-card:hover{transform:translateY(-5px);box-shadow:0 14px 32px #0000001f}.stats-top{display:flex;gap:14px;align-items:center}.stats-icon{width:120px;height:80px;border-top-left-radius:14px;border-bottom-right-radius:14px;display:flex;align-items:center;justify-content:center}.stats-text{display:flex;flex-direction:column}mat-icon{font-size:48px;width:48px;height:48px;line-height:48px}.stats-body{padding:18px}.stats-title{font-size:14px;color:#6b7280;margin-bottom:4px}.stats-bottom{display:flex;justify-content:space-between;align-items:flex-end;max-width:20px}.stats-value{font-size:28px;font-weight:700;color:#111827}.stats-trend{font-size:13px;font-weight:600}.stats-trend.up{color:#16a34a}.stats-trend.down{color:#dc2626}.stats-sub{font-size:13px;color:#9ca3af}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DashboardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-dashboard', imports: [MatIconModule], template: "<div class=\"container-fluid\">\n  <div class=\"row g-4\">\n    @for (card of cards; track $index) {\n      <div class=\"col-xl-3 col-lg-4 col-md-6 col-sm-12\">\n        <a (click)=\"onClick(card.href)\" class=\"text-decoration-none\">\n          <div class=\"card stats-card h-100\">\n            <!-- icon -->\n            <div class=\"stats-top\">\n              <div\n                class=\"stats-icon\"\n                [style.background]=\"\n                  card.iconBg || 'linear-gradient(135deg,#3b82f6,#2563eb)'\n                \"\n                [style.color]=\"card.iconColor || 'white'\"\n              >\n                <mat-icon class=\"stats-icon-size\">{{\n                  ICONS[card.icon]\n                }}</mat-icon>\n              </div>\n              <div class=\"stats-text\">\n                <div class=\"stats-title\">{{ card.title }}</div>\n                @if (card.subtitle) {\n                  <div class=\"stats-sub\">{{ card.subtitle }}</div>\n                }\n              </div>\n            </div>\n          </div>\n\n          <div class=\"stats-bottom\">\n            <div class=\"stats-value\">{{ card.value }}</div>\n\n            @if (card.trend) {\n              <div\n                class=\"stats-trend\"\n                [class.up]=\"card.trendUp\"\n                [class.down]=\"card.trendUp === false\"\n              >\n                {{ card.trend }}\n              </div>\n            }\n          </div>\n        </a>\n      </div>\n    }\n  </div>\n</div>\n", styles: [".stats-card{border:none;border-radius:18px;background:#fff;transition:all .25s ease;box-shadow:0 8px 24px #0000000f;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}.stats-card:hover{transform:translateY(-5px);box-shadow:0 14px 32px #0000001f}.stats-top{display:flex;gap:14px;align-items:center}.stats-icon{width:120px;height:80px;border-top-left-radius:14px;border-bottom-right-radius:14px;display:flex;align-items:center;justify-content:center}.stats-text{display:flex;flex-direction:column}mat-icon{font-size:48px;width:48px;height:48px;line-height:48px}.stats-body{padding:18px}.stats-title{font-size:14px;color:#6b7280;margin-bottom:4px}.stats-bottom{display:flex;justify-content:space-between;align-items:flex-end;max-width:20px}.stats-value{font-size:28px;font-weight:700;color:#111827}.stats-trend{font-size:13px;font-weight:600}.stats-trend.up{color:#16a34a}.stats-trend.down{color:#dc2626}.stats-sub{font-size:13px;color:#9ca3af}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.Router }, { type: i1$1.ActivatedRoute }], propDecorators: { cards: [{
                type: Input
            }] } });

class DashboardV2Component {
    router;
    route;
    cards = [];
    ICONS = ICONS;
    constructor(router, route) {
        this.router = router;
        this.route = route;
    }
    onClick(href) {
        this.router.navigate([href], { relativeTo: this.route });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DashboardV2Component, deps: [{ token: i1$1.Router }, { token: i1$1.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: DashboardV2Component, isStandalone: true, selector: "app-dashboard-v2", inputs: { cards: "cards" }, ngImport: i0, template: "<!-- <div class=\"container-fluid\">\n  <div class=\"row g-4\">\n    @for (card of cards; track $index) {\n      <div class=\"col-xl-3 col-lg-4 col-md-6 col-sm-12\">\n        <a [href]=\"card.href || '#'\" class=\"text-decoration-none\">\n          <div class=\"card stats-card h-160\">\n\n            <div class=\"stats-top\">\n              <div\n                class=\"stats-icon\"\n                [style.background]=\"\n                  card.iconBg || 'linear-gradient(135deg,#3b82f6,#2563eb)'\n                \"\n                [style.color]=\"card.iconColor || 'white'\"\n              >\n                <mat-icon class=\"stats-icon-size\">{{\n                  ICONS[card.icon]\n                }}</mat-icon>\n              </div>\n            </div>\n\n            <div class=\"stats-bottom\">\n              <div class=\"stats-title\">{{ card.title }}</div>\n              <br />\n              <div class=\"stats-title\">{{ card.subtitle }}</div>\n            </div>\n          </div>\n        </a>\n      </div>\n    }\n  </div>\n</div> -->\n\n\n<div class=\"container-fluid\">\n  <div class=\"row g-4\">\n    @for (card of cards; track $index) {\n      <div class=\"col-xl-3 col-lg-4 col-md-6 col-sm-12\">\n        <a (click)=\"onClick(card.href)\" class=\"text-decoration-none dashboard-link\">\n          <div class=\"card stats-card h-100\">\n\n            <!-- ICON HEADER -->\n            <div\n              class=\"stats-icon\"\n              [style.background]=\"card.iconBg || 'linear-gradient(135deg,#3b82f6,#2563eb)'\"\n              [style.color]=\"card.iconColor || 'white'\"\n            >\n              <mat-icon class=\"stats-icon-size\">\n                {{ ICONS[card.icon] }}\n              </mat-icon>\n            </div>\n\n            <!-- BODY -->\n            <div class=\"stats-body\">\n              <div class=\"stats-title\">{{ card.title }}</div>\n\n              <div class=\"stats-row\">\n                <div class=\"stats-title\">{{ card.subtitle }}</div>\n                <mat-icon class=\"arrow\">arrow_forward</mat-icon>\n              </div>\n            </div>\n\n          </div>\n        </a>\n      </div>\n    }\n  </div>\n</div>", styles: [".stats-card{border:none;border-radius:18px;background:#fff;transition:all .25s ease;box-shadow:0 8px 24px #0000000f;overflow:hidden;min-height:260px}.stats-card:hover{transform:translateY(-5px);box-shadow:0 14px 32px #0000001f}.stats-icon{width:100%;height:180px;display:flex;align-items:center;justify-content:center}mat-icon{font-size:48px;width:48px;height:48px}.stats-body{flex:1;padding-left:15px;padding-top:15px;display:flex;flex-direction:column;justify-content:space-between}.stats-title{align-self:flex-start;font-size:20px;font-weight:300;color:#292828;margin-bottom:10px}.stats-row{display:flex;justify-content:space-between}.stats-subtitle{font-size:14px;color:#6b7280}.arrow{align-self:flex-end;font-size:20px;color:#9ca3af;transition:transform .2s ease}.dashboard-link:hover .arrow{transform:translate(4px)}.dashboard-link{display:block;height:100%}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DashboardV2Component, decorators: [{
            type: Component,
            args: [{ selector: 'app-dashboard-v2', imports: [MatIconModule], template: "<!-- <div class=\"container-fluid\">\n  <div class=\"row g-4\">\n    @for (card of cards; track $index) {\n      <div class=\"col-xl-3 col-lg-4 col-md-6 col-sm-12\">\n        <a [href]=\"card.href || '#'\" class=\"text-decoration-none\">\n          <div class=\"card stats-card h-160\">\n\n            <div class=\"stats-top\">\n              <div\n                class=\"stats-icon\"\n                [style.background]=\"\n                  card.iconBg || 'linear-gradient(135deg,#3b82f6,#2563eb)'\n                \"\n                [style.color]=\"card.iconColor || 'white'\"\n              >\n                <mat-icon class=\"stats-icon-size\">{{\n                  ICONS[card.icon]\n                }}</mat-icon>\n              </div>\n            </div>\n\n            <div class=\"stats-bottom\">\n              <div class=\"stats-title\">{{ card.title }}</div>\n              <br />\n              <div class=\"stats-title\">{{ card.subtitle }}</div>\n            </div>\n          </div>\n        </a>\n      </div>\n    }\n  </div>\n</div> -->\n\n\n<div class=\"container-fluid\">\n  <div class=\"row g-4\">\n    @for (card of cards; track $index) {\n      <div class=\"col-xl-3 col-lg-4 col-md-6 col-sm-12\">\n        <a (click)=\"onClick(card.href)\" class=\"text-decoration-none dashboard-link\">\n          <div class=\"card stats-card h-100\">\n\n            <!-- ICON HEADER -->\n            <div\n              class=\"stats-icon\"\n              [style.background]=\"card.iconBg || 'linear-gradient(135deg,#3b82f6,#2563eb)'\"\n              [style.color]=\"card.iconColor || 'white'\"\n            >\n              <mat-icon class=\"stats-icon-size\">\n                {{ ICONS[card.icon] }}\n              </mat-icon>\n            </div>\n\n            <!-- BODY -->\n            <div class=\"stats-body\">\n              <div class=\"stats-title\">{{ card.title }}</div>\n\n              <div class=\"stats-row\">\n                <div class=\"stats-title\">{{ card.subtitle }}</div>\n                <mat-icon class=\"arrow\">arrow_forward</mat-icon>\n              </div>\n            </div>\n\n          </div>\n        </a>\n      </div>\n    }\n  </div>\n</div>", styles: [".stats-card{border:none;border-radius:18px;background:#fff;transition:all .25s ease;box-shadow:0 8px 24px #0000000f;overflow:hidden;min-height:260px}.stats-card:hover{transform:translateY(-5px);box-shadow:0 14px 32px #0000001f}.stats-icon{width:100%;height:180px;display:flex;align-items:center;justify-content:center}mat-icon{font-size:48px;width:48px;height:48px}.stats-body{flex:1;padding-left:15px;padding-top:15px;display:flex;flex-direction:column;justify-content:space-between}.stats-title{align-self:flex-start;font-size:20px;font-weight:300;color:#292828;margin-bottom:10px}.stats-row{display:flex;justify-content:space-between}.stats-subtitle{font-size:14px;color:#6b7280}.arrow{align-self:flex-end;font-size:20px;color:#9ca3af;transition:transform .2s ease}.dashboard-link:hover .arrow{transform:translate(4px)}.dashboard-link{display:block;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.Router }, { type: i1$1.ActivatedRoute }], propDecorators: { cards: [{
                type: Input
            }] } });

class AlertDialogComponent {
    dialogRef;
    type;
    title;
    subtitle;
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.type = data.type;
        this.title = data.title;
        this.subtitle = data.subtitle;
    }
    onSalir(b) {
        this.dialogRef.close(b);
    }
    onAceptar(b) {
        this.dialogRef.close(b);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AlertDialogComponent, deps: [{ token: i1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: AlertDialogComponent, isStandalone: true, selector: "app-dialog-alert", ngImport: i0, template: "<nz-result\n  nzTitle=\"Ocurrio un error\"\n  [nzStatus]=\"type\"\n  [nzTitle]=\"title\"\n  [nzSubTitle]=\"subtitle\"\n>\n  <div nz-result-extra>\n    @switch (type) {\n        @case ('warning') {\n            <button nz-button nzType=\"primary\" (click)=\"onAceptar(true)\">Aceptar</button>\n            <button nz-button nzType=\"dashed\" (click)=\"onSalir(false)\">Salir</button>\n        }\n        @case ('error') {\n            <button nz-button nzType=\"primary\" (click)=\"onSalir(true)\">Salir</button>\n        }\n        @case ('info') {\n            <button nz-button nzType=\"primary\" (click)=\"onAceptar(true)\">Aceptar</button>\n            <button nz-button nzType=\"dashed\" (click)=\"onSalir(false)\">Salir</button>\n        }\n        @case ('success') {\n            <button nz-button nzType=\"primary\" (click)=\"onAceptar(true)\">Aceptar</button>\n        }\n    }\n    \n  </div>\n</nz-result>\n", dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: NzButtonModule }, { kind: "component", type: i2$1.NzButtonComponent, selector: "button[nz-button], a[nz-button]", inputs: ["nzBlock", "nzGhost", "nzSearch", "nzLoading", "nzDanger", "disabled", "tabIndex", "nzType", "nzShape", "nzSize"], exportAs: ["nzButton"] }, { kind: "directive", type: i3.ɵNzTransitionPatchDirective, selector: "[nz-button], [nz-icon], nz-icon, [nz-menu-item], [nz-submenu], nz-select-top-control, nz-select-placeholder, nz-input-group", inputs: ["hidden"] }, { kind: "directive", type: i4$1.NzWaveDirective, selector: "[nz-wave],button[nz-button]:not([nzType=\"link\"]):not([nzType=\"text\"])", inputs: ["nzWaveExtraNode"], exportAs: ["nzWave"] }, { kind: "ngmodule", type: NzResultModule }, { kind: "component", type: i5.NzResultComponent, selector: "nz-result", inputs: ["nzIcon", "nzTitle", "nzSubTitle", "nzExtra", "nzStatus"], exportAs: ["nzResult"] }, { kind: "directive", type: i5.NzResultExtraDirective, selector: "div[nz-result-extra]", exportAs: ["nzResultExtra"] }, { kind: "ngmodule", type: NzTypographyModule }, { kind: "ngmodule", type: NzIconModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AlertDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-dialog-alert', imports: [
                        MatDialogModule,
                        NzButtonModule,
                        NzResultModule,
                        NzTypographyModule,
                        NzIconModule,
                    ], template: "<nz-result\n  nzTitle=\"Ocurrio un error\"\n  [nzStatus]=\"type\"\n  [nzTitle]=\"title\"\n  [nzSubTitle]=\"subtitle\"\n>\n  <div nz-result-extra>\n    @switch (type) {\n        @case ('warning') {\n            <button nz-button nzType=\"primary\" (click)=\"onAceptar(true)\">Aceptar</button>\n            <button nz-button nzType=\"dashed\" (click)=\"onSalir(false)\">Salir</button>\n        }\n        @case ('error') {\n            <button nz-button nzType=\"primary\" (click)=\"onSalir(true)\">Salir</button>\n        }\n        @case ('info') {\n            <button nz-button nzType=\"primary\" (click)=\"onAceptar(true)\">Aceptar</button>\n            <button nz-button nzType=\"dashed\" (click)=\"onSalir(false)\">Salir</button>\n        }\n        @case ('success') {\n            <button nz-button nzType=\"primary\" (click)=\"onAceptar(true)\">Aceptar</button>\n        }\n    }\n    \n  </div>\n</nz-result>\n" }]
        }], ctorParameters: () => [{ type: i1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class FilterComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FilterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: FilterComponent, isStandalone: true, selector: "app-filter", ngImport: i0, template: "<mat-accordion class=\"example-headers-align\" multi>\n  <mat-expansion-panel>\n    <mat-expansion-panel-header>\n      <mat-panel-title>\n        <mat-icon>search</mat-icon>\n        Buscador\n      </mat-panel-title>\n    </mat-expansion-panel-header>\n    <ng-content select=\"[body]\"></ng-content>\n     <ng-content select=\"[footer]\"></ng-content>\n  </mat-expansion-panel>\n</mat-accordion>\n", dependencies: [{ kind: "ngmodule", type: MatExpansionModule }, { kind: "directive", type: i1$2.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i1$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i1$2.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i1$2.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FilterComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-filter', imports: [MatExpansionModule, MatIconModule], template: "<mat-accordion class=\"example-headers-align\" multi>\n  <mat-expansion-panel>\n    <mat-expansion-panel-header>\n      <mat-panel-title>\n        <mat-icon>search</mat-icon>\n        Buscador\n      </mat-panel-title>\n    </mat-expansion-panel-header>\n    <ng-content select=\"[body]\"></ng-content>\n     <ng-content select=\"[footer]\"></ng-content>\n  </mat-expansion-panel>\n</mat-accordion>\n" }]
        }] });

// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';
// import { ComboType } from '../models/combo-type';
// import { ApiHttpService } from 'lib-servicios';
// @Injectable({
//   providedIn: 'root',
// })
// export class ComboHttpService {
//   private url = '';
//   constructor(
//     private http: ApiHttpService,
//     private config: CoreLibService,
//   ) {
//     this.url = config.loginUrl + 'v1/combo/';
//   }
//   getCombo(type: string, extraParams?: any): Observable<ComboType[]> {
//     const fullUrl = this.url + 'get';
//     const params = {
//       type,
//       ...(extraParams ?? {}),
//     };
//     return this.http.get<ComboType[]>(fullUrl, params);
//   }
// }
// combo-data-provider.ts
const COMBO_DATA_PROVIDER = new InjectionToken('COMBO_DATA_PROVIDER');

class ComboComponent {
    dataProvider;
    zone;
    ngControl;
    matSelect;
    label;
    type = '';
    isLocal = false;
    data = [];
    readonly = false;
    extraParams;
    data$;
    value = null;
    disabled = this.readonly;
    loaded = false;
    loading = false;
    onChange = (_) => { };
    onTouched = () => { };
    constructor(dataProvider, zone, ngControl) {
        this.dataProvider = dataProvider;
        this.zone = zone;
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        // this.control..
    }
    ngOnChanges(changes) {
        if (changes['extraParams'] && !changes['extraParams'].firstChange) {
            this.loaded = false;
            this.loadData();
        }
        if (changes['type'] && !changes['type'].firstChange) {
            this.loaded = false;
            this.loadData();
        }
    }
    loadData() {
        this.data$ = this.isLocal
            ? of(this.data)
            : this.dataProvider.getDataCombo(this.type, this.extraParams);
    }
    writeValue(value) {
        this.value = value;
        // 🔥 si viene valor y todavía no cargaste datos, cargalos
        if (value != null && !this.loaded && !this.loading) {
            this.loading = true;
            const obs = this.isLocal
                ? of(this.data)
                : this.dataProvider.getDataCombo(this.type, this.extraParams);
            obs.pipe(take(1)).subscribe((data) => {
                this.data$ = of(data);
                this.loaded = true;
                this.loading = false;
                // esperar render para que mat-select tome el valor
                queueMicrotask(() => {
                    this.matSelect?.writeValue(this.value);
                });
            });
            return;
        }
        // caso normal
        queueMicrotask(() => {
            this.matSelect?.writeValue(this.value);
        });
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onSelectionChange(value) {
        this.value = value;
        this.onChange(value);
        this.onTouched();
    }
    handleClick() {
        if (this.loaded || this.loading)
            return;
        this.loading = true;
        const obs = this.isLocal
            ? of(this.data)
            : this.dataProvider.getDataCombo(this.type, this.extraParams);
        obs.subscribe((data) => {
            this.data$ = of(data);
            this.loaded = true;
            this.loading = false;
            // 🔥 esperar a que Angular termine de renderizar
            this.zone.onStable.pipe(take(1)).subscribe(() => {
                if (!this.matSelect.panelOpen) {
                    this.matSelect.open();
                }
            });
        });
    }
    clear() {
        this.onSelectionChange(null);
    }
    trackByNumero = (_, item) => item.numero;
    compareByNumero = (a, b) => {
        return a === b;
    };
    getDescripcion(items) {
        if (!items)
            return '';
        const found = items.find((x) => x.numero === this.value);
        return found?.descripcion ?? '';
    }
    get control() {
        return this.ngControl?.control;
    }
    get showError() {
        return !!this.control && this.control.invalid && this.control.touched;
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['email'])
            return `Formato inválido`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        if (errors['max'])
            return `Máximo ${errors['max'].requiredLength}`;
        if (errors['min'])
            return `Mínimo ${errors['min'].requiredLength}`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ComboComponent, deps: [{ token: COMBO_DATA_PROVIDER }, { token: i0.NgZone }, { token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: ComboComponent, isStandalone: true, selector: "app-combo", inputs: { label: "label", type: "type", isLocal: "isLocal", data: "data", readonly: "readonly", extraParams: "extraParams" }, viewQueries: [{ propertyName: "matSelect", first: true, predicate: MatSelect, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<mat-form-field #mat appearance=\"fill\" style=\"width: 100%\" (click)=\"handleClick()\">\n  <mat-label>{{ label }}</mat-label>\n\n  <!-- <mat-select\n    [value]=\"value\"\n    [disabled]=\"disabled\"\n    [compareWith]=\"compareByNumero\"\n    (selectionChange)=\"onSelectionChange($event.value)\"\n    (openedChange)=\"readonly && $event ? $event = false : null\"\n  >\n    @for (item of data$ | async; track item.numero) {\n      <mat-option [value]=\"item.numero\">\n        {{ item.descripcion }}\n      </mat-option>\n    }\n  </mat-select> -->\n\n  @if (!readonly) {\n    <mat-select\n      [value]=\"value\"\n      [disabled]=\"disabled\"\n      [compareWith]=\"compareByNumero\"\n      [formControl]=\"control\"\n      (selectionChange)=\"onSelectionChange($event.value)\"\n      (click)=\"handleClick()\"\n    >\n      @for (item of data$ | async; track item.numero) {\n        <mat-option [value]=\"item.numero\">\n          {{ item.descripcion }}\n        </mat-option>\n      }\n    </mat-select>\n  } @else {\n    @let items = data$ | async;\n\n    <input matInput [value]=\"getDescripcion(items)\" readonly />\n  }\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      aria-label=\"Clear\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i2$2.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i2$2.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "ngmodule", type: IMaskModule }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ComboComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ComboComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-combo', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ComboComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatNativeDateModule,
                        MatDatepickerModule,
                        IMaskModule,
                    ], template: "<mat-form-field #mat appearance=\"fill\" style=\"width: 100%\" (click)=\"handleClick()\">\n  <mat-label>{{ label }}</mat-label>\n\n  <!-- <mat-select\n    [value]=\"value\"\n    [disabled]=\"disabled\"\n    [compareWith]=\"compareByNumero\"\n    (selectionChange)=\"onSelectionChange($event.value)\"\n    (openedChange)=\"readonly && $event ? $event = false : null\"\n  >\n    @for (item of data$ | async; track item.numero) {\n      <mat-option [value]=\"item.numero\">\n        {{ item.descripcion }}\n      </mat-option>\n    }\n  </mat-select> -->\n\n  @if (!readonly) {\n    <mat-select\n      [value]=\"value\"\n      [disabled]=\"disabled\"\n      [compareWith]=\"compareByNumero\"\n      [formControl]=\"control\"\n      (selectionChange)=\"onSelectionChange($event.value)\"\n      (click)=\"handleClick()\"\n    >\n      @for (item of data$ | async; track item.numero) {\n        <mat-option [value]=\"item.numero\">\n          {{ item.descripcion }}\n        </mat-option>\n      }\n    </mat-select>\n  } @else {\n    @let items = data$ | async;\n\n    <input matInput [value]=\"getDescripcion(items)\" readonly />\n  }\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      aria-label=\"Clear\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n" }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [COMBO_DATA_PROVIDER]
                }] }, { type: i0.NgZone }, { type: i1$3.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { matSelect: [{
                type: ViewChild,
                args: [MatSelect]
            }], label: [{
                type: Input,
                args: [{ required: true }]
            }], type: [{
                type: Input
            }], isLocal: [{
                type: Input
            }], data: [{
                type: Input
            }], readonly: [{
                type: Input
            }], extraParams: [{
                type: Input
            }] } });

class DateFormFieldComponent {
    ngControl;
    datepickerInput;
    label;
    readonly = false;
    value = null;
    disabled = this.readonly;
    onChange = (_) => { };
    onTouched = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        this.value = value;
        // sincroniza el input real del datepicker
        if (this.datepickerInput) {
            this.datepickerInput.value = value;
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onDateChange(date) {
        this.value = date;
        this.onChange(date);
    }
    clear() {
        this.value = null;
        this.datepickerInput.value = null;
        this.onChange(null);
        this.onTouched();
    }
    get control() {
        return this.ngControl?.control;
    }
    get showError() {
        return !!this.control && this.control.invalid && this.control.touched;
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['email'])
            return `Formato inválido`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        if (errors['max'])
            return `Máximo ${errors['max'].requiredLength}`;
        if (errors['min'])
            return `Mínimo ${errors['min'].requiredLength}`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DateFormFieldComponent, deps: [{ token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: DateFormFieldComponent, isStandalone: true, selector: "app-date-form-field", inputs: { label: "label", readonly: "readonly" }, viewQueries: [{ propertyName: "datepickerInput", first: true, predicate: MatDatepickerInput, descendants: true }], ngImport: i0, template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    matInput\n    [matDatepicker]=\"picker\"\n    [value]=\"value\"\n    [disabled]=\"disabled\"\n    [readonly]=\"true\"\n    [formControl]=\"control\"\n    (dateChange)=\"onDateChange($event.value)\"\n    (blur)=\"onTouched()\"\n  />\n\n  <mat-datepicker-toggle\n    matIconSuffix\n    [for]=\"picker\"\n    [disabled]=\"readonly\"\n  ></mat-datepicker-toggle>\n  <mat-datepicker [disabled]=\"readonly\" #picker></mat-datepicker>\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      aria-label=\"Clear\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i5$1.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i5$1.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i5$1.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "ngmodule", type: IMaskModule }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => DateFormFieldComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DateFormFieldComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-date-form-field', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => DateFormFieldComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatNativeDateModule,
                        MatDatepickerModule,
                        IMaskModule
                    ], template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    matInput\n    [matDatepicker]=\"picker\"\n    [value]=\"value\"\n    [disabled]=\"disabled\"\n    [readonly]=\"true\"\n    [formControl]=\"control\"\n    (dateChange)=\"onDateChange($event.value)\"\n    (blur)=\"onTouched()\"\n  />\n\n  <mat-datepicker-toggle\n    matIconSuffix\n    [for]=\"picker\"\n    [disabled]=\"readonly\"\n  ></mat-datepicker-toggle>\n  <mat-datepicker [disabled]=\"readonly\" #picker></mat-datepicker>\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      aria-label=\"Clear\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n" }]
        }], ctorParameters: () => [{ type: i1$3.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { datepickerInput: [{
                type: ViewChild,
                args: [MatDatepickerInput]
            }], label: [{
                type: Input,
                args: [{ required: true }]
            }], readonly: [{
                type: Input
            }] } });

const APP_DATE_FORMATS = {
    parse: {
        dateInput: 'DD-MM-YYYY',
    },
    display: {
        dateInput: 'DD-MM-YYYY',
        monthYearLabel: 'MMMM YYYY',
        dateA11yLabel: 'DD-MM-YYYY',
        monthYearA11yLabel: 'MMMM YYYY',
    },
};

class DecimalFormFieldComponent {
    ngControl;
    inputRef;
    label;
    readonly = false;
    disabled = false;
    decimals = 2;
    value = null;
    maskRef;
    onChange = (_) => { };
    onTouched = () => { };
    maskOptions;
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        this.maskOptions = {
            mask: Number,
            scale: this.decimals,
            signed: false,
            thousandsSeparator: '.',
            radix: ',',
            mapToRadix: ['.'],
            normalizeZeros: true,
        };
    }
    onAccept(e) {
        const raw = e; // tu valor actual
        const normalized = raw
            .replace(/\./g, '') // sacar miles
            .replace(',', '.'); // decimal a punto
        const value = Number(normalized);
        this.value = value;
        this.onChange(value);
    }
    writeValue(value) {
        this.value = value;
        // setear valor en IMask
        const input = this.inputRef?.nativeElement;
        if (!input)
            return;
        if (value == null) {
            input.value = '';
            return;
        }
        // formatear manualmente para IMask
        const formatted = value.toFixed(this.decimals).replace('.', ',');
        input.value = formatted;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    clear() {
        this.value = null;
        this.onChange(null);
        const el = this.inputRef.nativeElement;
        if (el?.maskRef) {
            el.maskRef.value = '';
        }
    }
    handleBlur() {
        this.onTouched();
    }
    get control() {
        return this.ngControl.control;
    }
    get showError() {
        // return !!this.control && this.control.invalid && this.control.touched;
        const c = this.control;
        return !!c && c.invalid && (c.touched || c.dirty);
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['email'])
            return `Formato inválido`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        if (errors['max'])
            return `Máximo ${errors['max'].requiredLength}`;
        if (errors['min'])
            return `Mínimo ${errors['min'].requiredLength}`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DecimalFormFieldComponent, deps: [{ token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: DecimalFormFieldComponent, isStandalone: true, selector: "app-decimal-form-field", inputs: { label: "label", readonly: "readonly", disabled: "disabled", decimals: "decimals", value: "value" }, viewQueries: [{ propertyName: "inputRef", first: true, predicate: ["input"], descendants: true, static: true }], ngImport: i0, template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    matInput\n    type=\"text\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [imask]=\"maskOptions\"\n    (accept)=\"onAccept($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: IMaskModule }, { kind: "directive", type: i5$2.IMaskDirective, selector: "[imask]", inputs: ["imask", "unmask", "imaskElement"], outputs: ["accept", "complete"], exportAs: ["imask"] }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => DecimalFormFieldComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DecimalFormFieldComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-decimal-form-field', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => DecimalFormFieldComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        IMaskModule,
                    ], template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    matInput\n    type=\"text\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [imask]=\"maskOptions\"\n    (accept)=\"onAccept($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n" }]
        }], ctorParameters: () => [{ type: i1$3.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { inputRef: [{
                type: ViewChild,
                args: ['input', { static: true }]
            }], label: [{
                type: Input,
                args: [{ required: true }]
            }], readonly: [{
                type: Input
            }], disabled: [{
                type: Input
            }], decimals: [{
                type: Input
            }], value: [{
                type: Input
            }] } });

class FormFieldComponent {
    ngControl;
    label;
    readonly = false;
    inputRef;
    value = null;
    disabled = false;
    onChange = (_) => { };
    onTouched = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        if (!value)
            return;
        this.value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onInput(value) {
        this.value = value;
        this.onChange(value);
    }
    onBlur() {
        this.onTouched();
    }
    clear() {
        this.value = null;
        this.onChange(null);
        this.onTouched();
        queueMicrotask(() => this.inputRef?.nativeElement.focus());
    }
    get control() {
        return this.ngControl?.control;
    }
    get showError() {
        return !!this.control && this.control.invalid && this.control.touched;
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['email'])
            return `Formato inválido`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        if (errors['max'])
            return `Máximo ${errors['max'].requiredLength}`;
        if (errors['min'])
            return `Mínimo ${errors['min'].requiredLength}`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormFieldComponent, deps: [{ token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: FormFieldComponent, isStandalone: true, selector: "app-form-field", inputs: { label: "label", readonly: "readonly" }, viewQueries: [{ propertyName: "inputRef", first: true, predicate: ["input"], descendants: true, static: true }], ngImport: i0, template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    matInput\n    type=\"text\"\n    [value]=\"value\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [formControl]=\"control\"\n    (input)=\"onInput($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  />\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "ngmodule", type: IMaskModule }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => FormFieldComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormFieldComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-form-field', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => FormFieldComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatNativeDateModule,
                        MatDatepickerModule,
                        IMaskModule
                    ], template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    matInput\n    type=\"text\"\n    [value]=\"value\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [formControl]=\"control\"\n    (input)=\"onInput($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  />\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n" }]
        }], ctorParameters: () => [{ type: i1$3.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { label: [{
                type: Input,
                args: [{ required: true }]
            }], readonly: [{
                type: Input
            }], inputRef: [{
                type: ViewChild,
                args: ['input', { static: true }]
            }] } });

class NumberFormFieldComponent {
    ngControl;
    label;
    readonly = false;
    inputRef;
    value = null;
    disabled = false;
    onChange = (_) => { };
    onTouched = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        this.value = value;
        if (value === null) {
            this.inputRef.nativeElement.value = '';
        }
        else {
            this.inputRef.nativeElement.value = this.format(value);
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onInput(raw) {
        const digits = raw.replace(/\D/g, '');
        if (!digits) {
            this.value = null;
            this.onChange(null);
            this.inputRef.nativeElement.value = '';
            return;
        }
        const parsed = Number(digits);
        this.value = parsed;
        this.onChange(parsed);
        this.inputRef.nativeElement.value = this.format(parsed);
    }
    onBlur() {
        this.onTouched();
    }
    clear() {
        this.value = null;
        this.onChange(null);
        this.onTouched();
        queueMicrotask(() => this.inputRef?.nativeElement.focus());
    }
    format(value) {
        return value.toLocaleString('es-AR');
    }
    get control() {
        return this.ngControl?.control;
    }
    get showError() {
        return !!this.control && this.control.invalid && this.control.touched;
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['email'])
            return `Formato inválido`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        if (errors['max'])
            return `Máximo ${errors['max'].max}`;
        if (errors['min'])
            return `Mínimo ${errors['min'].min}`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NumberFormFieldComponent, deps: [{ token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: NumberFormFieldComponent, isStandalone: true, selector: "app-number-form-field", inputs: { label: "label", readonly: "readonly" }, viewQueries: [{ propertyName: "inputRef", first: true, predicate: ["input"], descendants: true, static: true }], ngImport: i0, template: "<mat-form-field\n  appearance=\"fill\"\n  style=\"width: 100%\"\n>\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    matInput\n    type=\"text\"\n    pattern=\"[0-9]+\"\n    inputmode=\"numeric\"\n    [value]=\"value ?? ''\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [formControl]=\"control\"\n    (input)=\"onInput($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  />\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$3.PatternValidator, selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]", inputs: ["pattern"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "ngmodule", type: IMaskModule }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => NumberFormFieldComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NumberFormFieldComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-number-form-field', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => NumberFormFieldComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatNativeDateModule,
                        MatDatepickerModule,
                        IMaskModule
                    ], template: "<mat-form-field\n  appearance=\"fill\"\n  style=\"width: 100%\"\n>\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    matInput\n    type=\"text\"\n    pattern=\"[0-9]+\"\n    inputmode=\"numeric\"\n    [value]=\"value ?? ''\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [formControl]=\"control\"\n    (input)=\"onInput($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  />\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n" }]
        }], ctorParameters: () => [{ type: i1$3.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { label: [{
                type: Input,
                args: [{ required: true }]
            }], readonly: [{
                type: Input
            }], inputRef: [{
                type: ViewChild,
                args: ['input', { static: true }]
            }] } });

class TextareaFormFieldComponent {
    ngControl;
    label;
    readonly = false;
    textareaRef;
    value = null;
    disabled = false;
    onChange = (_) => { };
    onTouched = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onInput(value) {
        this.value = value;
        this.onChange(value);
    }
    onBlur() {
        this.onTouched();
    }
    clear() {
        this.value = null;
        this.onChange(null);
        this.onTouched();
        queueMicrotask(() => this.textareaRef?.nativeElement.focus());
    }
    get control() {
        return this.ngControl?.control;
    }
    get showError() {
        return !!this.control && this.control.invalid && this.control.touched;
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['email'])
            return `Formato inválido`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        if (errors['max'])
            return `Máximo ${errors['max'].requiredLength}`;
        if (errors['min'])
            return `Mínimo ${errors['min'].requiredLength}`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: TextareaFormFieldComponent, deps: [{ token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: TextareaFormFieldComponent, isStandalone: true, selector: "app-textarea-form-field", inputs: { label: "label", readonly: "readonly" }, viewQueries: [{ propertyName: "textareaRef", first: true, predicate: ["input"], descendants: true, static: true }], ngImport: i0, template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <textarea\n    #input\n    matInput\n    [value]=\"value\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [formControl]=\"control\"\n    (input)=\"onInput($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  >\n  </textarea>\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "ngmodule", type: IMaskModule }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => TextareaFormFieldComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: TextareaFormFieldComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-textarea-form-field', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => TextareaFormFieldComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatNativeDateModule,
                        MatDatepickerModule,
                        IMaskModule
                    ], template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <textarea\n    #input\n    matInput\n    [value]=\"value\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [formControl]=\"control\"\n    (input)=\"onInput($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  >\n  </textarea>\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n" }]
        }], ctorParameters: () => [{ type: i1$3.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { label: [{
                type: Input,
                args: [{ required: true }]
            }], readonly: [{
                type: Input
            }], textareaRef: [{
                type: ViewChild,
                args: ['input', { static: true }]
            }] } });

class ViajeMaskComponent {
    ngControl;
    label;
    readonly = false;
    inputRef;
    value = null;
    disabled = false;
    maskRef;
    onChange = (_) => { };
    onTouched = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    ngAfterViewInit() {
        queueMicrotask(() => {
            this.maskRef = IMask(this.inputRef.nativeElement, {
                mask: 'V-{NNNNNNNN}',
                lazy: false,
                overwrite: true,
                blocks: {
                    NNNNNNNN: {
                        mask: IMask.MaskedNumber,
                        scale: 0,
                        min: 0,
                        max: 99999999,
                    },
                },
            });
            this.maskRef.on('accept', () => {
                const val = this.maskRef.value || null;
                this.value = val;
                this.onChange(val);
            });
            this.maskRef.on('blur', () => this.onTouched());
        });
    }
    writeValue(value) {
        this.value = value;
        if (this.maskRef)
            this.maskRef.value = value ?? '';
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        if (this.maskRef)
            this.maskRef.updateOptions({ lazy: isDisabled });
    }
    clear() {
        this.value = null;
        this.maskRef.value = '';
        this.onChange(null);
        this.onTouched();
        queueMicrotask(() => this.inputRef.nativeElement.focus());
    }
    get control() {
        return this.ngControl?.control;
    }
    get showError() {
        return !!this.control && this.control.invalid && this.control.touched;
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['email'])
            return `Formato inválido`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        if (errors['max'])
            return `Máximo ${errors['max'].requiredLength}`;
        if (errors['min'])
            return `Mínimo ${errors['min'].requiredLength}`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ViajeMaskComponent, deps: [{ token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: ViajeMaskComponent, isStandalone: true, selector: "app-viaje-mask", inputs: { label: "label", readonly: "readonly" }, viewQueries: [{ propertyName: "inputRef", first: true, predicate: ["input"], descendants: true, static: true }], ngImport: i0, template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    matInput\n    type=\"text\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    placeholder=\"V-00000000\"\n    [formControl]=\"control\"\n  />\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "ngmodule", type: IMaskModule }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ViajeMaskComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ViajeMaskComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-viaje-mask', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ViajeMaskComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatNativeDateModule,
                        MatDatepickerModule,
                        IMaskModule
                    ], template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    matInput\n    type=\"text\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    placeholder=\"V-00000000\"\n    [formControl]=\"control\"\n  />\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n" }]
        }], ctorParameters: () => [{ type: i1$3.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { label: [{
                type: Input,
                args: [{ required: true }]
            }], readonly: [{
                type: Input
            }], inputRef: [{
                type: ViewChild,
                args: ['input', { static: true }]
            }] } });

class MultipleComboComponent {
    dataProvider;
    ngControl;
    matSelect;
    label;
    type = '';
    isLocal = false;
    data = [];
    readonly = false;
    extraParams;
    data$;
    value = [];
    disabled = this.readonly;
    search = '';
    filteredData$;
    pendingValue = [];
    onChange = (_) => { };
    onTouched = () => { };
    constructor(dataProvider, ngControl) {
        this.dataProvider = dataProvider;
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.loadData();
        this.filteredData$ = this.data$.pipe(map((items) => items.filter((x) => x.descripcion.toLowerCase().includes(this.search.toLowerCase()))));
    }
    ngOnChanges(changes) {
        if (changes['extraParams'] && !changes['extraParams'].firstChange) {
            this.loadData();
        }
        if (changes['type'] && !changes['type'].firstChange) {
            this.loadData();
        }
    }
    loadData() {
        this.data$ = this.isLocal
            ? of(this.data)
            : this.dataProvider.getDataCombo(this.type, this.extraParams);
    }
    writeValue(value) {
        this.value = value ?? [];
        queueMicrotask(() => {
            if (this.matSelect) {
                this.matSelect.writeValue(this.value);
            }
        });
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onSelectionChange(value) {
        this.value = value;
        this.onChange(value);
        this.onTouched();
    }
    clear() {
        this.onSelectionChange([]);
    }
    trackByNumero = (_, item) => item.numero;
    compareByNumero = (a, b) => a === b;
    onSearchChange(value) {
        this.search = value;
        this.filteredData$ = this.data$.pipe(map((items) => items.filter((x) => x.descripcion.toLowerCase().includes(value.toLowerCase()))));
    }
    getDescripcion(items) {
        if (!items || !this.value?.length)
            return '';
        const seleccionados = items.filter((x) => this.value.includes(x.numero));
        return seleccionados.map((x) => x.descripcion).join(', ');
    }
    get control() {
        return this.ngControl?.control;
    }
    get showError() {
        return !!this.control && this.control.invalid && this.control.touched;
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['email'])
            return `Formato inválido`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        if (errors['max'])
            return `Máximo ${errors['max'].requiredLength}`;
        if (errors['min'])
            return `Mínimo ${errors['min'].requiredLength}`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MultipleComboComponent, deps: [{ token: COMBO_DATA_PROVIDER }, { token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: MultipleComboComponent, isStandalone: true, selector: "app-multiple-combo", inputs: { label: "label", type: "type", isLocal: "isLocal", data: "data", readonly: "readonly", extraParams: "extraParams" }, viewQueries: [{ propertyName: "matSelect", first: true, predicate: MatSelect, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  @if (!readonly) {\n    <mat-select\n      [value]=\"value\"\n      [disabled]=\"disabled\"\n      [compareWith]=\"compareByNumero\"\n      (selectionChange)=\"onSelectionChange($event.value)\"\n      [formControl]=\"control\"\n      multiple\n    >\n      <mat-option disabled>\n        <input\n          matInput\n          placeholder=\"Buscar...\"\n          (input)=\"onSearchChange($event.target.value)\"\n          (click)=\"$event.stopPropagation()\"\n        />\n      </mat-option>\n\n      @for (item of data$ | async; track item.numero) {\n        <mat-option [value]=\"item.numero\">\n          {{ item.descripcion }}\n        </mat-option>\n      }\n    </mat-select>\n  } @else {\n    @let items = data$ | async;\n\n    <input matInput [value]=\"getDescripcion(items)\" readonly />\n  }\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      aria-label=\"Clear\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "component", type: i2$2.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i2$2.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "ngmodule", type: IMaskModule }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => MultipleComboComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MultipleComboComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-multiple-combo', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => MultipleComboComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatNativeDateModule,
                        MatDatepickerModule,
                        IMaskModule
                    ], template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  @if (!readonly) {\n    <mat-select\n      [value]=\"value\"\n      [disabled]=\"disabled\"\n      [compareWith]=\"compareByNumero\"\n      (selectionChange)=\"onSelectionChange($event.value)\"\n      [formControl]=\"control\"\n      multiple\n    >\n      <mat-option disabled>\n        <input\n          matInput\n          placeholder=\"Buscar...\"\n          (input)=\"onSearchChange($event.target.value)\"\n          (click)=\"$event.stopPropagation()\"\n        />\n      </mat-option>\n\n      @for (item of data$ | async; track item.numero) {\n        <mat-option [value]=\"item.numero\">\n          {{ item.descripcion }}\n        </mat-option>\n      }\n    </mat-select>\n  } @else {\n    @let items = data$ | async;\n\n    <input matInput [value]=\"getDescripcion(items)\" readonly />\n  }\n\n  @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      aria-label=\"Clear\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background-color: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>\n" }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [COMBO_DATA_PROVIDER]
                }] }, { type: i1$3.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { matSelect: [{
                type: ViewChild,
                args: [MatSelect]
            }], label: [{
                type: Input,
                args: [{ required: true }]
            }], type: [{
                type: Input
            }], isLocal: [{
                type: Input
            }], data: [{
                type: Input
            }], readonly: [{
                type: Input
            }], extraParams: [{
                type: Input
            }] } });

class CuitMaskComponent {
    ngControl;
    imask;
    label;
    readonly = false;
    inputRef;
    value = null;
    disabled = false;
    mask = {
        mask: '00-00000000-0',
        lazy: false,
    };
    onChange = (_) => { };
    onTouched = () => { };
    constructor(ngControl) {
        this.ngControl = ngControl;
        if (this.ngControl) {
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        if (value === null || value === undefined) {
            this.value = null;
            if (this.imask)
                this.imask.maskValue = '';
            return;
        }
        const str = String(value);
        this.value = str;
        if (this.imask) {
            this.imask.maskValue = str;
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onAccept(masked) {
        if (!masked) {
            this.value = null;
            this.onChange(null);
            this.control?.setErrors(null);
            return;
        }
        const limpio = masked.replace(/\D/g, '');
        this.value = masked;
        // const numero = limpio ? Number(limpio) : null;
        // this.onChange(numero);
        this.onChange(limpio || null);
        if (limpio.length === 11) {
            const valido = this.validarCUIT(limpio);
            if (!valido) {
                this.control?.setErrors({ cuitInvalido: true });
            }
            else {
                const errors = this.control?.errors;
                if (errors) {
                    delete errors['cuitInvalido'];
                    if (Object.keys(errors).length === 0) {
                        this.control.setErrors(null);
                    }
                    else {
                        this.control.setErrors(errors);
                    }
                }
            }
        }
    }
    onBlur() {
        this.onTouched();
    }
    clear() {
        this.value = null;
        this.onChange(null);
        this.onTouched();
        queueMicrotask(() => this.inputRef?.nativeElement.focus());
    }
    validarCUIT(cuit) {
        if (cuit.length !== 11)
            return false;
        // const mult = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
        // const nums = cuit.split('').map(Number);
        // const total = mult.reduce((acc, m, i) => acc + m * nums[i], 0);
        // const mod = 11 - (total % 11);
        // const digito = mod === 11 ? 0 : mod === 10 ? 9 : mod;
        // return digito === nums[10];
        return true;
    }
    get control() {
        return this.ngControl?.control;
    }
    get showError() {
        return !!this.control && this.control.invalid && this.control.touched;
    }
    get errorMessage() {
        const errors = this.control?.errors;
        if (!errors)
            return null;
        if (errors['required'])
            return `${this.label} es obligatorio`;
        if (errors['maxlength'])
            return `Máximo ${errors['maxlength'].requiredLength} caracteres`;
        if (errors['minlength'])
            return `Mínimo ${errors['minlength'].requiredLength} caracteres`;
        return 'Valor inválido';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CuitMaskComponent, deps: [{ token: i1$3.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: CuitMaskComponent, isStandalone: true, selector: "app-cuit-mask", inputs: { label: "label", readonly: "readonly" }, viewQueries: [{ propertyName: "imask", first: true, predicate: IMaskDirective, descendants: true, static: true }, { propertyName: "inputRef", first: true, predicate: ["input"], descendants: true, static: true }], ngImport: i0, template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    #imask=\"imask\"\n    matInput\n    type=\"text\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [imask]=\"mask\"\n    (accept)=\"onAccept($event)\"\n    (blur)=\"onBlur()\"\n  />\n\n @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "ngmodule", type: IMaskModule }, { kind: "directive", type: i5$2.IMaskDirective, selector: "[imask]", inputs: ["imask", "unmask", "imaskElement"], outputs: ["accept", "complete"], exportAs: ["imask"] }], viewProviders: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => CuitMaskComponent),
                multi: true,
            },
        ] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CuitMaskComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-cuit-mask', viewProviders: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => CuitMaskComponent),
                            multi: true,
                        },
                    ], imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatIconModule,
                        MatNativeDateModule,
                        MatDatepickerModule,
                        IMaskModule,
                    ], template: "<mat-form-field appearance=\"fill\" style=\"width: 100%\">\n  <mat-label>{{ label }}</mat-label>\n\n  <input\n    #input\n    #imask=\"imask\"\n    matInput\n    type=\"text\"\n    [readonly]=\"readonly\"\n    [disabled]=\"disabled\"\n    [imask]=\"mask\"\n    (accept)=\"onAccept($event)\"\n    (blur)=\"onBlur()\"\n  />\n\n @if (value && !readonly) {\n    <button\n      matSuffix\n      mat-icon-button\n      type=\"button\"\n      (click)=\"clear()\"\n      style=\"border-color: transparent; background: transparent\"\n      tabindex=\"-1\"\n    >\n      <mat-icon>close</mat-icon>\n    </button>\n  }\n\n  @if (showError) {\n    <mat-error>{{ errorMessage }}</mat-error>\n  }\n</mat-form-field>" }]
        }], ctorParameters: () => [{ type: i1$3.NgControl, decorators: [{
                    type: Self
                }, {
                    type: Optional
                }] }], propDecorators: { imask: [{
                type: ViewChild,
                args: [IMaskDirective, { static: true }]
            }], label: [{
                type: Input,
                args: [{ required: true }]
            }], readonly: [{
                type: Input
            }], inputRef: [{
                type: ViewChild,
                args: ['input', { static: true }]
            }] } });

class DynamicFormatPipe {
    locale = inject(LOCALE_ID);
    decimalPipe = new DecimalPipe(this.locale);
    datePipe = new DatePipe(this.locale);
    transform(value, type, format) {
        if (value == null)
            return '';
        if (type === 'numeric') {
            return this.formatNumber(Number(value), format ?? '1.0-2');
        }
        if (type === 'date') {
            return this.formatDate(value, format ?? 'dd/MM/yyyy');
        }
        return value;
    }
    formatNumber(value, format) {
        switch (format) {
            case '{0:2}':
                return this.decimalPipe.transform(value, '1.2-2');
            case '{0:1}':
                return this.decimalPipe.transform(value, '1.1-1');
            case 'cuit':
                return this.formatCuit(value);
            default:
                return value;
        }
    }
    formatDate(value, format) {
        switch (format) {
            case 'ddMMyyyy hh:MM:ss':
                return this.datePipe.transform(value, 'dd/MM/yyyy HH:mm:ss');
            case 'ddMMyyyy hh:MM':
                return this.datePipe.transform(value, 'dd/MM/yyyy HH:mm');
            case 'ddMMyy':
                return this.datePipe.transform(value, 'dd/MM/yy');
            case 'ddMM':
                return this.datePipe.transform(value, 'dd/MM');
            default:
                return this.datePipe.transform(value, 'dd/MM/yyyy');
        }
    }
    formatCuit(value) {
        const digits = String(Math.trunc(value));
        const limpio = digits.replace(/\D/g, '');
        if (limpio.length !== 11)
            return limpio;
        return `${limpio.slice(0, 2)}-${limpio.slice(2, 10)}-${limpio.slice(10)}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DynamicFormatPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: DynamicFormatPipe, isStandalone: true, name: "dynamicFormat" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DynamicFormatPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'dynamicFormat',
                    standalone: true,
                }]
        }] });

class GridComponent {
    dataService;
    config;
    hiddenRefresh = false;
    isLocal = false;
    ref;
    data = [];
    columns = [];
    menuActions = [];
    toolbarButtons = [];
    selectableSettings;
    checked = false;
    indeterminate = false;
    total = 10;
    ICONS = ICONS;
    activeFilterColumn;
    searchValue = new FormControl('');
    filterVisible = {};
    editableService;
    selectedRows = [];
    selectedRowsChange = new EventEmitter();
    selectedSet = new Set();
    destroy$ = new Subject();
    ngOnInit() {
        this.columns = this.buildConfgColumns(this.config.columns);
        this.menuActions = this.config.menuActions ?? [];
        this.toolbarButtons = this.config.toolBarActions ?? [];
        this.selectableSettings = this.config.selectableSettings ?? this.defaultSelectable();
        if (this.config.isEditable && this.isEditableService(this.dataService)) {
            this.editableService = this.dataService;
        }
        if (!this.ref) {
            this.ref = this.dataService.ref;
        }
        this.dataService.data$.pipe(takeUntil(this.destroy$)).subscribe((data) => {
            this.data = data;
            this.buildEditCache();
            this.resetSelectionStatus();
        });
        this.dataService.total$
            .pipe(takeUntil(this.destroy$))
            .subscribe((t) => (this.total = t));
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    onPageSizeChange() {
        this.dataService.search();
    }
    //Defaluts
    buildConfgColumns(columns) {
        return columns.map(value => {
            return {
                ...value,
                sortable: value.sortable ?? true,
                filter: value.filter ?? false,
                hidden: value.hidden ?? false
            };
        });
    }
    defaultSelectable() {
        return {
            type: "single",
            selectable: true
        };
    }
    //Metodos para seleccionar
    isChecked(row) {
        return this.selectedSet.has(row);
    }
    onRowChecked(row, checked) {
        if (!this.selectableSettings?.selectable)
            return;
        if (this.selectableSettings.type === 'single') {
            if (checked) {
                this.selectedSet.clear();
                this.selectedSet.add(row);
            }
            else {
                this.selectedSet.delete(row);
            }
        }
        else {
            checked ? this.selectedSet.add(row) : this.selectedSet.delete(row);
        }
        this.refreshSelectionStatus();
    }
    onAllChecked(checked) {
        if (!this.selectableSettings?.selectable)
            return;
        const selectableRows = this.data.filter((r) => this.isRowSelectable(r));
        if (this.selectableSettings.type === 'single') {
            this.selectedSet.clear();
        }
        else {
            selectableRows.forEach((row) => {
                checked ? this.selectedSet.add(row) : this.selectedSet.delete(row);
            });
        }
        this.refreshSelectionStatus();
    }
    refreshSelectionStatus() {
        const pageData = this.data;
        const selectedOnPage = pageData.filter((r) => this.selectedSet.has(r)).length;
        this.checked = selectedOnPage > 0 && selectedOnPage === pageData.length;
        this.indeterminate = selectedOnPage > 0 && selectedOnPage < pageData.length;
        this.selectedRows = Array.from(this.selectedSet);
        this.selectedRowsChange.emit(this.selectedRows);
    }
    resetSelectionStatus() {
        this.selectedSet.clear();
        this.selectedRows = [];
        this.checked = false;
        this.indeterminate = false;
        this.selectedRowsChange.emit(this.selectedRows);
    }
    isRowSelectable(row) {
        if (!this.selectableSettings?.selectable)
            return false;
        if (!this.selectableSettings.esSelectable)
            return true;
        return this.selectableSettings.esSelectable(row);
    }
    get leftButtons() {
        return this.config.toolBarActions?.filter(a => a.position !== 'right') ?? [];
    }
    get rightButtons() {
        return this.config.toolBarActions?.filter(a => a.position === 'right') ?? [];
    }
    // Filtros y ordenamiento
    hasFilter(key) {
        return !!this.dataService.state.filters?.[key];
    }
    onFilterVisibleChange(visible, column) {
        if (!visible)
            return;
        this.activeFilterColumn = column.key.toString();
        this.searchValue.setValue(this.dataService.state.filters?.[column.key] ?? '');
    }
    applyFilter(field) {
        this.dataService.setFilter(field, this.searchValue.getRawValue());
        this.filterVisible[field] = false;
    }
    resetFilter(field) {
        this.dataService.setFilter(field, null);
        this.filterVisible[field] = false;
        this.searchValue.reset();
    }
    getSortOrder(key) {
        const sort = this.dataService.state.sort;
        if (!sort || sort.field !== key)
            return null;
        return sort.direction === 'asc' ? 'ascend' : 'descend';
    }
    onSort(key, order) {
        if (!order) {
            this.dataService.setSort(key, null);
            return;
        }
        const direction = order === 'ascend' ? 'asc' : 'desc';
        this.dataService.setSort(key, direction);
    }
    // Para editable
    trackRow = (index, row) => {
        if (!this.editableService)
            return String(index);
        try {
            return this.editableService.getRowKey(row);
        }
        catch {
            return String(index);
        }
    };
    isEditableService(svc) {
        return svc && typeof svc.getRowKey === 'function' && typeof svc.update === 'function';
    }
    editCache = {};
    editingId;
    buildEditCache() {
        if (!this.editableService)
            return;
        const newCache = {};
        for (const row of this.data) {
            const key = this.editableService.getRowKey(row);
            newCache[key] = this.editCache[key] ?? {
                edit: false,
                data: structuredClone(row),
            };
        }
        this.editCache = newCache;
    }
    startEdit(row) {
        if (!this.editableService)
            return;
        const key = this.editableService.getRowKey(row);
        this.editingId = key;
        this.editCache[key].edit = true;
    }
    cancelEdit(row) {
        if (!this.editableService)
            return;
        const key = this.editableService.getRowKey(row);
        this.editCache[key].edit = false;
        this.editCache[key].data = structuredClone(row);
        this.editingId = undefined;
    }
    addRow() {
        if (!this.editableService)
            return;
        const newRow = {};
        this.editableService.add(newRow);
        // esperar microtask para que data$ actualice
        setTimeout(() => {
            const added = this.data[0]; // porque usás unshift
            this.startEdit(added);
        });
    }
    saveEdit(row) {
        if (!this.editableService)
            return;
        const key = this.editableService.getRowKey(row);
        const edited = this.editCache[key].data;
        this.editCache[key].edit = false;
        this.editingId = undefined;
        Object.assign(row, edited);
        this.editableService.update(row);
    }
    removeEdit(row) {
        if (!this.editableService)
            return;
        const key = this.editableService.getRowKey(row);
        const edited = this.editCache[key].data;
        Object.assign(row, edited);
        this.editableService.remove(row);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GridComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: GridComponent, isStandalone: true, selector: "app-grid", inputs: { dataService: "dataService", config: "config", hiddenRefresh: "hiddenRefresh", isLocal: "isLocal", ref: "ref", selectedRows: "selectedRows" }, outputs: { selectedRowsChange: "selectedRowsChange" }, ngImport: i0, template: "<!-- TOOLBAR -->\n<div class=\"grid-toolbar\">\n  <!-- IZQUIERDA -->\n  <div class=\"toolbar-left\">\n    @if (editableService) {\n      <button\n        type=\"button\"\n        class=\"btn btn-outline-secondary toolbar-icon-btn\"\n        (click)=\"addRow()\"\n      >\n        <mat-icon>add</mat-icon>\n      </button>\n    }\n\n    @for (action of leftButtons; track action.key) {\n      <app-button\n        [hidden]=\"action.hidden\"\n        [disabled]=\"\n          (action.disabledOnEmptyRows && selectedRows.length === 0) ||\n          (action.disabled ? action.disabled(selectedRows) : false)\n        \"\n        [icon]=\"action.icon\"\n        (onClick)=\"action.onClick(selectedRows)\"\n        [label]=\"action.label\"\n        [type]=\"action.type\"\n        [ref]=\"ref\"\n      />\n    }\n  </div>\n\n  <!-- DERECHA -->\n  <div class=\"toolbar-right\">\n    @for (action of rightButtons; track action.key) {\n      <app-button\n        [hidden]=\"action.hidden\"\n        [disabled]=\"\n          (action.disabledOnEmptyRows && selectedRows.length === 0) ||\n          (action.disabled ? action.disabled(selectedRows) : false)\n        \"\n        [icon]=\"action.icon\"\n        (onClick)=\"action.onClick(selectedRows)\"\n        [label]=\"action.label\"\n        [type]=\"action.type\"\n        [ref]=\"ref\"\n      />\n    }\n  </div>\n</div>\n\n<!-- TABLA -->\n<nz-table\n  [nzData]=\"data\"\n  [nzLoading]=\"ref.loading\"\n  [nzFrontPagination]=\"false\"\n  [nzTotal]=\"total\"\n  [(nzPageSize)]=\"dataService.state.pageSize\"\n  [(nzPageIndex)]=\"dataService.state.page\"\n  [nzShowSizeChanger]=\"true\"\n  [nzPageSizeOptions]=\"[10, 20, 50]\"\n  (nzPageSizeChange)=\"onPageSizeChange()\"\n  (nzPageIndexChange)=\"onPageSizeChange()\"\n  style=\"width: 100%; overflow-y: auto; margin-bottom: 20px\"\n>\n  <thead>\n    <tr>\n      @if (selectableSettings?.selectable) {\n        @if (selectableSettings?.type === \"multiple\") {\n          <th\n            nzShowCheckbox\n            [nzChecked]=\"checked\"\n            [nzIndeterminate]=\"indeterminate\"\n            (nzCheckedChange)=\"onAllChecked($event)\"\n          ></th>\n        } @else {\n          <th></th>\n        }\n      }\n\n      @if (editableService) {\n        <th>Edici\u00F3n</th>\n      }\n\n      @if (menuActions.length > 0) {\n        <th style=\"font-size: 14px\">Acciones</th>\n      }\n      @for (column of columns; track column.key) {\n        @if (column.filter) {\n          @if (column.sortable) {\n            <th\n              nzCustomFilter\n              style=\"font-size: 14px\"\n              [hidden]=\"column.hidden\"\n              [nzSortFn]=\"true\"\n              [nzSortOrder]=\"getSortOrder(column.key)\"\n              (nzSortOrderChange)=\"onSort(column.key, $event)\"\n            >\n              {{ column.title }}\n              <nz-filter-trigger\n                [(nzVisible)]=\"filterVisible[column.key.toString()]\"\n                [nzActive]=\"hasFilter(column.key)\"\n                [nzDropdownMenu]=\"filterMenu\"\n                (nzVisibleChange)=\"onFilterVisibleChange($event, column)\"\n              >\n                <nz-icon nzType=\"search\" />\n              </nz-filter-trigger>\n            </th>\n          } @else {\n            <th nzCustomFilter style=\"font-size: 14px\" [hidden]=\"column.hidden\">\n              {{ column.title }}\n              <nz-filter-trigger\n                [(nzVisible)]=\"filterVisible[column.key.toString()]\"\n                [nzActive]=\"hasFilter(column.key)\"\n                [nzDropdownMenu]=\"filterMenu\"\n                (nzVisibleChange)=\"onFilterVisibleChange($event, column)\"\n              >\n                <nz-icon nzType=\"search\" />\n              </nz-filter-trigger>\n            </th>\n          }\n        } @else {\n          @if (column.sortable) {\n            <th\n              style=\"font-size: 14px\"\n              [hidden]=\"column.hidden\"\n              [nzSortFn]=\"true\"\n              [nzSortOrder]=\"getSortOrder(column.key)\"\n              (nzSortOrderChange)=\"onSort(column.key, $event)\"\n            >\n              {{ column.title }}\n            </th>\n          } @else {\n            <th style=\"font-size: 14px\" [hidden]=\"column.hidden\">\n              {{ column.title }}\n            </th>\n          }\n        }\n      }\n    </tr>\n  </thead>\n\n  <tbody>\n    @for (row of data; track trackRow($index, row)) {\n      <tr>\n        <!-- CheckBox para seleccionar rows -->\n        @if (selectableSettings?.selectable) {\n          <td\n            nzShowCheckbox\n            [nzChecked]=\"isChecked(row)\"\n            [nzDisabled]=\"!isRowSelectable(row)\"\n            (nzCheckedChange)=\"onRowChecked(row, $event)\"\n          ></td>\n        }\n\n        <!-- EditableService -->\n        @if (editableService) {\n          <td [width]=\"50\">\n            @if (!editCache[editableService.getRowKey(row)].edit) {\n              <div style=\"display: flex; justify-content: space-between\">\n                <button\n                  type=\"button\"\n                  class=\"btn btn-link\"\n                  (click)=\"startEdit(row)\"\n                >\n                  Editar\n                </button>\n                <button\n                  type=\"button\"\n                  class=\"btn btn-link\"\n                  (click)=\"removeEdit(row)\"\n                >\n                  Remover\n                </button>\n              </div>\n            } @else {\n              <div style=\"display: flex; justify-content: space-between\">\n                <button\n                  type=\"button\"\n                  class=\"btn btn-link\"\n                  (click)=\"saveEdit(row)\"\n                >\n                  Guardar\n                </button>\n                <button\n                  type=\"button\"\n                  class=\"btn btn-link\"\n                  (click)=\"cancelEdit(row)\"\n                >\n                  Cancelar\n                </button>\n              </div>\n            }\n          </td>\n        }\n\n        <!-- Menu de acciones para las filas -->\n        @if (menuActions.length > 0) {\n          <td>\n            <button\n              class=\"btn btn-light\"\n              style=\"\n                display: flex;\n                border-radius: 100%;\n                background-color: transparent;\n              \"\n              [matMenuTriggerFor]=\"menu\"\n            >\n              <mat-icon>menu</mat-icon>\n            </button>\n\n            <mat-menu #menu=\"matMenu\" style=\"width: auto\">\n              @for (action of menuActions; track action.key) {\n                @if (!action.hidden || !action.hidden(row)) {\n                  <button mat-menu-item (click)=\"action.onClick(row)\">\n                    @if (action.icon) {\n                      <mat-icon style=\"margin-right: 8px\">{{\n                        ICONS[action.icon]\n                      }}</mat-icon>\n                    }\n                    {{ action.label }}\n                  </button>\n                }\n              }\n            </mat-menu>\n          </td>\n        }\n\n        <!-- Columnas normales -->\n        @for (column of columns; track column.key) {\n          <td style=\"font-size: 12px\" [hidden]=\"column.hidden\">\n            @if (\n              editableService &&\n              column.editable &&\n              editCache[editableService.getRowKey(row)].edit\n            ) {\n              @if (column.editTemplate) {\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    column.editTemplate;\n                    context: {\n                      $implicit: editCache[editableService.getRowKey(row)].data,\n                    }\n                  \"\n                />\n              } @else {\n                <app-form-field\n                  [label]=\"column.title\"\n                  [(ngModel)]=\"\n                    editCache[editableService.getRowKey(row)].data[column.key]\n                  \"\n                ></app-form-field>\n              }\n            } @else {\n              @if (column.type === 'template') {\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    column.template;\n                    context: {\n                      $implicit: row,\n                      row: row,\n                    }\n                  \"\n                />\n              } @else {\n                {{\n                  row[column.key] | dynamicFormat: column.type : column.format\n                }}\n              }\n            }\n          </td>\n        }\n      </tr>\n    }\n  </tbody>\n  <br />\n  @if (!hiddenRefresh) {\n    <div style=\"width: 100%\">\n      <button\n        type=\"button\"\n        class=\"btn btn-outline-secondary\"\n        style=\"display: flex\"\n        (click)=\"dataService.search()\"\n        [disabled]=\"ref.loading\"\n      >\n        <mat-icon>refresh</mat-icon>\n      </button>\n    </div>\n  }\n</nz-table>\n\n<nz-dropdown-menu #filterMenu=\"nzDropdownMenu\">\n  <div class=\"ant-table-filter-dropdown\">\n    <div class=\"search-box\">\n      <input\n        type=\"text\"\n        nz-input\n        placeholder=\"Search name\"\n        [formControl]=\"searchValue\"\n      />\n      <button\n        nz-button\n        nzSize=\"small\"\n        nzType=\"primary\"\n        nzClickHide=\"false\"\n        (click)=\"applyFilter(activeFilterColumn!)\"\n        class=\"search-button\"\n      >\n        Buscar\n      </button>\n      <button\n        nz-button\n        nzSize=\"small\"\n        nzClickHide=\"false\"\n        (click)=\"resetFilter(activeFilterColumn!)\"\n      >\n        Limpiar\n      </button>\n    </div>\n  </div>\n</nz-dropdown-menu>\n", styles: [".search-box{padding:8px}.search-box input{width:188px;margin-bottom:8px;display:block}.search-box button{width:90px}.search-button{margin-right:8px}.grid-toolbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:10px;flex-wrap:wrap}.toolbar-left,.toolbar-right{display:flex;align-items:center;gap:8px}.toolbar-right{margin-left:auto}.toolbar-icon-btn{display:flex;align-items:center;justify-content:center}\n"], dependencies: [{ kind: "ngmodule", type: NzTableModule }, { kind: "component", type: i1$4.NzTableComponent, selector: "nz-table", inputs: ["nzTableLayout", "nzShowTotal", "nzItemRender", "nzTitle", "nzFooter", "nzNoResult", "nzPageSizeOptions", "nzVirtualItemSize", "nzVirtualMaxBufferPx", "nzVirtualMinBufferPx", "nzVirtualForTrackBy", "nzLoadingDelay", "nzPageIndex", "nzPageSize", "nzTotal", "nzWidthConfig", "nzData", "nzCustomColumn", "nzPaginationPosition", "nzScroll", "noDataVirtualHeight", "nzPaginationType", "nzFrontPagination", "nzTemplateMode", "nzShowPagination", "nzLoading", "nzOuterBordered", "nzLoadingIndicator", "nzBordered", "nzSize", "nzShowSizeChanger", "nzHideOnSinglePage", "nzShowQuickJumper", "nzSimple"], outputs: ["nzPageSizeChange", "nzPageIndexChange", "nzQueryParams", "nzCurrentPageDataChange", "nzCustomColumnChange"], exportAs: ["nzTable"] }, { kind: "component", type: i1$4.NzThAddOnComponent, selector: "th[nzColumnKey], th[nzSortFn], th[nzSortOrder], th[nzFilters], th[nzShowSort], th[nzShowFilter], th[nzCustomFilter]", inputs: ["nzColumnKey", "nzFilterMultiple", "nzSortOrder", "nzSortPriority", "nzSortDirections", "nzFilters", "nzSortFn", "nzFilterFn", "nzShowSort", "nzShowFilter", "nzCustomFilter"], outputs: ["nzCheckedChange", "nzSortOrderChange", "nzFilterChange"] }, { kind: "directive", type: i1$4.NzTableCellDirective, selector: "th:not(.nz-disable-th), td:not(.nz-disable-td)" }, { kind: "directive", type: i1$4.NzThMeasureDirective, selector: "th", inputs: ["nzWidth", "colspan", "colSpan", "rowspan", "rowSpan"] }, { kind: "component", type: i1$4.NzTdAddOnComponent, selector: "td[nzChecked], td[nzDisabled], td[nzIndeterminate], td[nzIndentSize], td[nzExpand], td[nzShowExpand], td[nzShowCheckbox]", inputs: ["nzChecked", "nzDisabled", "nzIndeterminate", "nzLabel", "nzIndentSize", "nzShowExpand", "nzShowCheckbox", "nzExpand", "nzExpandIcon"], outputs: ["nzCheckedChange", "nzExpandChange"] }, { kind: "component", type: i1$4.NzTheadComponent, selector: "thead:not(.ant-table-thead)", outputs: ["nzSortOrderChange"] }, { kind: "component", type: i1$4.NzTbodyComponent, selector: "tbody" }, { kind: "directive", type: i1$4.NzTrDirective, selector: "tr:not([nz-table-measure-row]):not([nzExpand]):not([nz-table-fixed-row])" }, { kind: "component", type: i1$4.NzFilterTriggerComponent, selector: "nz-filter-trigger", inputs: ["nzActive", "nzDropdownMenu", "nzVisible", "nzBackdrop"], outputs: ["nzVisibleChange"], exportAs: ["nzFilterTrigger"] }, { kind: "component", type: i1$4.NzThSelectionComponent, selector: "th[nzSelections],th[nzChecked],th[nzShowCheckbox],th[nzShowRowSelection]", inputs: ["nzSelections", "nzChecked", "nzDisabled", "nzIndeterminate", "nzLabel", "nzShowCheckbox", "nzShowRowSelection"], outputs: ["nzCheckedChange"] }, { kind: "ngmodule", type: NzDropDownModule }, { kind: "component", type: i2$3.NzDropdownMenuComponent, selector: "nz-dropdown-menu", exportAs: ["nzDropdownMenu"] }, { kind: "ngmodule", type: NzIconModule }, { kind: "directive", type: i3$2.NzIconDirective, selector: "nz-icon,[nz-icon]", inputs: ["nzSpin", "nzRotate", "nzType", "nzTheme", "nzTwotoneColor", "nzIconfont"], exportAs: ["nzIcon"] }, { kind: "ngmodule", type: NzButtonModule }, { kind: "component", type: i2$1.NzButtonComponent, selector: "button[nz-button], a[nz-button]", inputs: ["nzBlock", "nzGhost", "nzSearch", "nzLoading", "nzDanger", "disabled", "tabIndex", "nzType", "nzShape", "nzSize"], exportAs: ["nzButton"] }, { kind: "directive", type: i3.ɵNzTransitionPatchDirective, selector: "[nz-button], [nz-icon], nz-icon, [nz-menu-item], [nz-submenu], nz-select-top-control, nz-select-placeholder, nz-input-group", inputs: ["hidden"] }, { kind: "directive", type: i4$1.NzWaveDirective, selector: "[nz-wave],button[nz-button]:not([nzType=\"link\"]):not([nzType=\"text\"])", inputs: ["nzWaveExtraNode"], exportAs: ["nzWave"] }, { kind: "ngmodule", type: NzMenuModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: ButtonComponent, selector: "app-button", inputs: ["ref", "key", "label", "icon", "type", "disabled", "hidden", "props"], outputs: ["onClick"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i8.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i8.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i8.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: NzFloatButtonModule }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: FormFieldComponent, selector: "app-form-field", inputs: ["label", "readonly"] }, { kind: "ngmodule", type: CommonModule }, { kind: "pipe", type: DynamicFormatPipe, name: "dynamicFormat" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GridComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-grid', imports: [
                        NzTableModule,
                        DynamicFormatPipe,
                        NzDropDownModule,
                        NzIconModule,
                        NzButtonModule,
                        NzMenuModule,
                        MatIconModule,
                        ButtonComponent,
                        MatMenuModule,
                        FormsModule,
                        ReactiveFormsModule,
                        NzFloatButtonModule,
                        NgTemplateOutlet,
                        FormFieldComponent,
                        CommonModule
                    ], template: "<!-- TOOLBAR -->\n<div class=\"grid-toolbar\">\n  <!-- IZQUIERDA -->\n  <div class=\"toolbar-left\">\n    @if (editableService) {\n      <button\n        type=\"button\"\n        class=\"btn btn-outline-secondary toolbar-icon-btn\"\n        (click)=\"addRow()\"\n      >\n        <mat-icon>add</mat-icon>\n      </button>\n    }\n\n    @for (action of leftButtons; track action.key) {\n      <app-button\n        [hidden]=\"action.hidden\"\n        [disabled]=\"\n          (action.disabledOnEmptyRows && selectedRows.length === 0) ||\n          (action.disabled ? action.disabled(selectedRows) : false)\n        \"\n        [icon]=\"action.icon\"\n        (onClick)=\"action.onClick(selectedRows)\"\n        [label]=\"action.label\"\n        [type]=\"action.type\"\n        [ref]=\"ref\"\n      />\n    }\n  </div>\n\n  <!-- DERECHA -->\n  <div class=\"toolbar-right\">\n    @for (action of rightButtons; track action.key) {\n      <app-button\n        [hidden]=\"action.hidden\"\n        [disabled]=\"\n          (action.disabledOnEmptyRows && selectedRows.length === 0) ||\n          (action.disabled ? action.disabled(selectedRows) : false)\n        \"\n        [icon]=\"action.icon\"\n        (onClick)=\"action.onClick(selectedRows)\"\n        [label]=\"action.label\"\n        [type]=\"action.type\"\n        [ref]=\"ref\"\n      />\n    }\n  </div>\n</div>\n\n<!-- TABLA -->\n<nz-table\n  [nzData]=\"data\"\n  [nzLoading]=\"ref.loading\"\n  [nzFrontPagination]=\"false\"\n  [nzTotal]=\"total\"\n  [(nzPageSize)]=\"dataService.state.pageSize\"\n  [(nzPageIndex)]=\"dataService.state.page\"\n  [nzShowSizeChanger]=\"true\"\n  [nzPageSizeOptions]=\"[10, 20, 50]\"\n  (nzPageSizeChange)=\"onPageSizeChange()\"\n  (nzPageIndexChange)=\"onPageSizeChange()\"\n  style=\"width: 100%; overflow-y: auto; margin-bottom: 20px\"\n>\n  <thead>\n    <tr>\n      @if (selectableSettings?.selectable) {\n        @if (selectableSettings?.type === \"multiple\") {\n          <th\n            nzShowCheckbox\n            [nzChecked]=\"checked\"\n            [nzIndeterminate]=\"indeterminate\"\n            (nzCheckedChange)=\"onAllChecked($event)\"\n          ></th>\n        } @else {\n          <th></th>\n        }\n      }\n\n      @if (editableService) {\n        <th>Edici\u00F3n</th>\n      }\n\n      @if (menuActions.length > 0) {\n        <th style=\"font-size: 14px\">Acciones</th>\n      }\n      @for (column of columns; track column.key) {\n        @if (column.filter) {\n          @if (column.sortable) {\n            <th\n              nzCustomFilter\n              style=\"font-size: 14px\"\n              [hidden]=\"column.hidden\"\n              [nzSortFn]=\"true\"\n              [nzSortOrder]=\"getSortOrder(column.key)\"\n              (nzSortOrderChange)=\"onSort(column.key, $event)\"\n            >\n              {{ column.title }}\n              <nz-filter-trigger\n                [(nzVisible)]=\"filterVisible[column.key.toString()]\"\n                [nzActive]=\"hasFilter(column.key)\"\n                [nzDropdownMenu]=\"filterMenu\"\n                (nzVisibleChange)=\"onFilterVisibleChange($event, column)\"\n              >\n                <nz-icon nzType=\"search\" />\n              </nz-filter-trigger>\n            </th>\n          } @else {\n            <th nzCustomFilter style=\"font-size: 14px\" [hidden]=\"column.hidden\">\n              {{ column.title }}\n              <nz-filter-trigger\n                [(nzVisible)]=\"filterVisible[column.key.toString()]\"\n                [nzActive]=\"hasFilter(column.key)\"\n                [nzDropdownMenu]=\"filterMenu\"\n                (nzVisibleChange)=\"onFilterVisibleChange($event, column)\"\n              >\n                <nz-icon nzType=\"search\" />\n              </nz-filter-trigger>\n            </th>\n          }\n        } @else {\n          @if (column.sortable) {\n            <th\n              style=\"font-size: 14px\"\n              [hidden]=\"column.hidden\"\n              [nzSortFn]=\"true\"\n              [nzSortOrder]=\"getSortOrder(column.key)\"\n              (nzSortOrderChange)=\"onSort(column.key, $event)\"\n            >\n              {{ column.title }}\n            </th>\n          } @else {\n            <th style=\"font-size: 14px\" [hidden]=\"column.hidden\">\n              {{ column.title }}\n            </th>\n          }\n        }\n      }\n    </tr>\n  </thead>\n\n  <tbody>\n    @for (row of data; track trackRow($index, row)) {\n      <tr>\n        <!-- CheckBox para seleccionar rows -->\n        @if (selectableSettings?.selectable) {\n          <td\n            nzShowCheckbox\n            [nzChecked]=\"isChecked(row)\"\n            [nzDisabled]=\"!isRowSelectable(row)\"\n            (nzCheckedChange)=\"onRowChecked(row, $event)\"\n          ></td>\n        }\n\n        <!-- EditableService -->\n        @if (editableService) {\n          <td [width]=\"50\">\n            @if (!editCache[editableService.getRowKey(row)].edit) {\n              <div style=\"display: flex; justify-content: space-between\">\n                <button\n                  type=\"button\"\n                  class=\"btn btn-link\"\n                  (click)=\"startEdit(row)\"\n                >\n                  Editar\n                </button>\n                <button\n                  type=\"button\"\n                  class=\"btn btn-link\"\n                  (click)=\"removeEdit(row)\"\n                >\n                  Remover\n                </button>\n              </div>\n            } @else {\n              <div style=\"display: flex; justify-content: space-between\">\n                <button\n                  type=\"button\"\n                  class=\"btn btn-link\"\n                  (click)=\"saveEdit(row)\"\n                >\n                  Guardar\n                </button>\n                <button\n                  type=\"button\"\n                  class=\"btn btn-link\"\n                  (click)=\"cancelEdit(row)\"\n                >\n                  Cancelar\n                </button>\n              </div>\n            }\n          </td>\n        }\n\n        <!-- Menu de acciones para las filas -->\n        @if (menuActions.length > 0) {\n          <td>\n            <button\n              class=\"btn btn-light\"\n              style=\"\n                display: flex;\n                border-radius: 100%;\n                background-color: transparent;\n              \"\n              [matMenuTriggerFor]=\"menu\"\n            >\n              <mat-icon>menu</mat-icon>\n            </button>\n\n            <mat-menu #menu=\"matMenu\" style=\"width: auto\">\n              @for (action of menuActions; track action.key) {\n                @if (!action.hidden || !action.hidden(row)) {\n                  <button mat-menu-item (click)=\"action.onClick(row)\">\n                    @if (action.icon) {\n                      <mat-icon style=\"margin-right: 8px\">{{\n                        ICONS[action.icon]\n                      }}</mat-icon>\n                    }\n                    {{ action.label }}\n                  </button>\n                }\n              }\n            </mat-menu>\n          </td>\n        }\n\n        <!-- Columnas normales -->\n        @for (column of columns; track column.key) {\n          <td style=\"font-size: 12px\" [hidden]=\"column.hidden\">\n            @if (\n              editableService &&\n              column.editable &&\n              editCache[editableService.getRowKey(row)].edit\n            ) {\n              @if (column.editTemplate) {\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    column.editTemplate;\n                    context: {\n                      $implicit: editCache[editableService.getRowKey(row)].data,\n                    }\n                  \"\n                />\n              } @else {\n                <app-form-field\n                  [label]=\"column.title\"\n                  [(ngModel)]=\"\n                    editCache[editableService.getRowKey(row)].data[column.key]\n                  \"\n                ></app-form-field>\n              }\n            } @else {\n              @if (column.type === 'template') {\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    column.template;\n                    context: {\n                      $implicit: row,\n                      row: row,\n                    }\n                  \"\n                />\n              } @else {\n                {{\n                  row[column.key] | dynamicFormat: column.type : column.format\n                }}\n              }\n            }\n          </td>\n        }\n      </tr>\n    }\n  </tbody>\n  <br />\n  @if (!hiddenRefresh) {\n    <div style=\"width: 100%\">\n      <button\n        type=\"button\"\n        class=\"btn btn-outline-secondary\"\n        style=\"display: flex\"\n        (click)=\"dataService.search()\"\n        [disabled]=\"ref.loading\"\n      >\n        <mat-icon>refresh</mat-icon>\n      </button>\n    </div>\n  }\n</nz-table>\n\n<nz-dropdown-menu #filterMenu=\"nzDropdownMenu\">\n  <div class=\"ant-table-filter-dropdown\">\n    <div class=\"search-box\">\n      <input\n        type=\"text\"\n        nz-input\n        placeholder=\"Search name\"\n        [formControl]=\"searchValue\"\n      />\n      <button\n        nz-button\n        nzSize=\"small\"\n        nzType=\"primary\"\n        nzClickHide=\"false\"\n        (click)=\"applyFilter(activeFilterColumn!)\"\n        class=\"search-button\"\n      >\n        Buscar\n      </button>\n      <button\n        nz-button\n        nzSize=\"small\"\n        nzClickHide=\"false\"\n        (click)=\"resetFilter(activeFilterColumn!)\"\n      >\n        Limpiar\n      </button>\n    </div>\n  </div>\n</nz-dropdown-menu>\n", styles: [".search-box{padding:8px}.search-box input{width:188px;margin-bottom:8px;display:block}.search-box button{width:90px}.search-button{margin-right:8px}.grid-toolbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:10px;flex-wrap:wrap}.toolbar-left,.toolbar-right{display:flex;align-items:center;gap:8px}.toolbar-right{margin-left:auto}.toolbar-icon-btn{display:flex;align-items:center;justify-content:center}\n"] }]
        }], propDecorators: { dataService: [{
                type: Input,
                args: [{ required: true }]
            }], config: [{
                type: Input,
                args: [{ required: true }]
            }], hiddenRefresh: [{
                type: Input
            }], isLocal: [{
                type: Input
            }], ref: [{
                type: Input
            }], selectedRows: [{
                type: Input
            }], selectedRowsChange: [{
                type: Output
            }] } });

class BaseGridService {
    dataSub$ = new BehaviorSubject([]);
    totalSub$ = new BehaviorSubject(0);
    ref = { loading: false };
    data$ = this.dataSub$.asObservable();
    total$ = this.totalSub$.asObservable();
    state = {
        page: 1,
        pageSize: 10,
        filters: {}
    };
    setData(data, total) {
        this.dataSub$.next(data);
        this.totalSub$.next(total);
    }
    search() {
        //
        this.getData(this.state, this.ref)
            .subscribe((res) => {
            this.setData(res.items, res.total);
        });
    }
    setSort(field, direction) {
        if (!direction) {
            this.state.sort = undefined;
        }
        else {
            this.state.sort = { field, direction };
        }
        this.search();
    }
    setFilter(field, value) {
        if (!this.state.filters)
            this.state.filters = {};
        if (!value)
            delete this.state.filters[field];
        else
            this.state.filters[field] = value;
        this.search();
    }
}

class LocalGridService extends BaseGridService {
    items = [];
    constructor(initialData = []) {
        super();
        this.items = [...initialData];
    }
    wrap(data) {
        return { __uuid: crypto.randomUUID(), data };
    }
    unwrap(items) {
        return items.map((i) => i.data);
    }
    getData(state) {
        let data = [...this.items];
        // FILTROS
        if (state.filters) {
            Object.entries(state.filters).forEach(([key, value]) => {
                if (!value)
                    return;
                data = data.filter(({ data }) => {
                    const v = data[key];
                    return v
                        ?.toString()
                        .toLowerCase()
                        .includes(value.toString().toLowerCase());
                });
            });
        }
        // SORT
        if (state.sort) {
            const { field, direction } = state.sort;
            data.sort((a, b) => {
                const av = a.data[field];
                const bv = b.data[field];
                if (av === bv)
                    return 0;
                const res = av > bv ? 1 : -1;
                return direction === 'asc' ? res : -res;
            });
        }
        const total = data.length;
        // PAGINADO
        const start = (state.page - 1) * state.pageSize;
        const page = data.slice(start, start + state.pageSize);
        return of({
            items: this.unwrap(page),
            total,
        });
    }
    // CRUD SEGURO
    add(item) {
        this.items.unshift(this.wrap(item));
        this.search();
    }
    remove(item) {
        const id = this.findId(item);
        this.items = this.items.filter((i) => i.__uuid !== id);
        this.search();
    }
    update(item) {
        const id = this.findId(item);
        this.items = this.items.map((i) => i.__uuid === id ? { ...i, data: item } : i);
        this.search();
    }
    setAll(data) {
        this.items = data.map((d) => this.wrap(d));
        this.search();
    }
    clear() {
        this.items = [];
        this.search();
    }
    findId(item) {
        const found = this.items.find((i) => i.data === item);
        if (!found)
            throw new Error('Item no encontrado en LocalGridService');
        return found.__uuid;
    }
}

class EditableGridService extends LocalGridService {
    alertService;
    constructor(alertService) {
        super();
        this.alertService = alertService;
    }
    getRowKey(row) {
        const found = this.items.find((i) => i.data === row);
        if (!found) {
            console.log('Row no encontrada');
            throw new Error('Row no encontrada en EditableGridService');
        }
        return found.__uuid;
    }
}

const uuid = () => {
    return crypto.randomUUID();
};

class GridColumn {
    key;
    title;
    type;
    format;
    filter = false;
    hidden = false;
    sortable = true;
    editable = false;
    template;
    editTemplate;
}
class GridMenuAction {
    key;
    label;
    icon;
    hidden;
    disabled;
    onClick;
}
class GridToolBarAction {
    key;
    label;
    icon;
    type = 'primary';
    hidden;
    disabledOnEmptyRows = false;
    disabled;
    onClick;
    position;
}
class SelectebleSettings {
    type = 'single';
    selectable = true;
    esSelectable;
}

class AlertService {
    dialog;
    constructor(dialog) {
        this.dialog = dialog;
    }
    error$(title, subtitle) {
        return this.dialog.open(AlertDialogComponent, { data: { type: 'error', title, subtitle }, width: '600px' }).afterClosed();
    }
    success$(title, subtitle) {
        return this.dialog.open(AlertDialogComponent, { data: { type: 'success', title, subtitle }, width: '600px' }).afterClosed();
    }
    info$(title, subtitle) {
        return this.dialog.open(AlertDialogComponent, { data: { type: 'info', title, subtitle }, width: '600px' }).afterClosed();
    }
    warning$(title, subtitle) {
        return this.dialog.open(AlertDialogComponent, { data: { type: 'warning', title, subtitle }, width: '600px' }).afterClosed();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AlertService, deps: [{ token: i1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AlertService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AlertService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.MatDialog }] });

class GlobalSpinnerComponent {
    loadingService;
    constructor(loadingService) {
        this.loadingService = loadingService;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GlobalSpinnerComponent, deps: [{ token: i1$5.LoadingService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: GlobalSpinnerComponent, isStandalone: true, selector: "app-global-spinner", ngImport: i0, template: `
    @if (loadingService.loading$ | async) {
      <div class="overlay">
        <div class="spinner-box">
          <div class="spinner"></div>
          <p>{{ loadingService.message$ | async }}</p>
        </div>
      </div>
    }
  `, isInline: true, styles: [".overlay{position:fixed;inset:0;background:#00000059;display:flex;align-items:center;justify-content:center;z-index:9999}.spinner-box{background:#fff;padding:24px 32px;border-radius:8px;text-align:center}.spinner{width:32px;height:32px;border:3px solid #ccc;border-top:3px solid #333;border-radius:50%;animation:spin .8s linear infinite;margin:0 auto 12px}@keyframes spin{to{transform:rotate(360deg)}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "pipe", type: i2.AsyncPipe, name: "async" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GlobalSpinnerComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-global-spinner', template: `
    @if (loadingService.loading$ | async) {
      <div class="overlay">
        <div class="spinner-box">
          <div class="spinner"></div>
          <p>{{ loadingService.message$ | async }}</p>
        </div>
      </div>
    }
  `, imports: [CommonModule, AsyncPipe], styles: [".overlay{position:fixed;inset:0;background:#00000059;display:flex;align-items:center;justify-content:center;z-index:9999}.spinner-box{background:#fff;padding:24px 32px;border-radius:8px;text-align:center}.spinner{width:32px;height:32px;border:3px solid #ccc;border-top:3px solid #333;border-radius:50%;animation:spin .8s linear infinite;margin:0 auto 12px}@keyframes spin{to{transform:rotate(360deg)}}\n"] }]
        }], ctorParameters: () => [{ type: i1$5.LoadingService }] });

class FadeInComponent {
    speed = 'normal';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FadeInComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: FadeInComponent, isStandalone: true, selector: "app-fade-in", inputs: { speed: "speed" }, ngImport: i0, template: `
    <div class="fade-wrapper" [class.fast]="speed === 'fast'">
      <ng-content />
    </div>
  `, isInline: true, styles: [".fade-wrapper{animation:fadeSlide .35s ease-out}.fade-wrapper.fast{animation:fadeSlide .2s ease-out}@keyframes fadeSlide{0%{opacity:0;transform:translateY(15px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FadeInComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-fade-in', standalone: true, template: `
    <div class="fade-wrapper" [class.fast]="speed === 'fast'">
      <ng-content />
    </div>
  `, styles: [".fade-wrapper{animation:fadeSlide .35s ease-out}.fade-wrapper.fast{animation:fadeSlide .2s ease-out}@keyframes fadeSlide{0%{opacity:0;transform:translateY(15px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}\n"] }]
        }], propDecorators: { speed: [{
                type: Input
            }] } });

/**
 * Servicio base para el UploadFilesComponent.
 *
 * Implementalo para conectar el componente con la API que quieras.
 * El componente no sabe nada de tu backend: solo llama a estos metodos.
 *
 * - `upload`   (obligatorio): sube un archivo y devuelve la respuesta.
 * - `list`     (opcional): devuelve los archivos ya cargados para mostrarlos al iniciar.
 * - `download` (opcional): descarga un archivo ya cargado.
 * - `remove`   (opcional): elimina un archivo del servidor.
 */
class BaseUploadService {
    /** (Opcional) Devuelve los archivos ya cargados para mostrarlos al iniciar. */
    list;
    /** (Opcional) Descarga un archivo ya cargado. */
    download;
    /** (Opcional) Elimina un archivo del servidor. */
    remove;
}

/**
 * Componente generico para subir archivos.
 *
 * Se maneja con un `BaseUploadService` que le pasas por `[service]`.
 * El servicio decide contra que API pega. Ejemplo de uso:
 *
 * ```html
 * <app-upload-files [service]="miUploadService"></app-upload-files>
 * ```
 */
class UploadFilesComponent {
    /** Servicio que resuelve las operaciones contra la API. */
    service;
    /** Permite seleccionar varios archivos a la vez. */
    multiple = true;
    /** Tipos aceptados (ej: '.pdf,.png,image/*'). */
    accept;
    /** Estilo de la lista: 'text' | 'picture' | 'picture-card'. */
    listType = 'text';
    /** Tamanio maximo por archivo en KB (0 = sin limite). */
    maxSizeKb = 0;
    /** Deshabilita el componente. */
    disabled = false;
    /** Texto del boton disparador. */
    buttonText = 'Seleccionar archivos';
    /** Si el servicio implementa `list`, carga los archivos existentes al iniciar. */
    loadExisting = true;
    /** Lista de archivos (soporta two-way binding). */
    fileList = [];
    fileListChange = new EventEmitter();
    /** Se emite cuando un archivo termina de subirse. */
    uploaded = new EventEmitter();
    /** Se emite cuando un archivo se elimina. */
    removed = new EventEmitter();
    /** Se emite en cada cambio de estado (ver ejemplo nzChange). */
    changed = new EventEmitter();
    ngOnInit() {
        if (this.service.list) {
            this.service.list().subscribe((files) => {
                this.fileList = files ?? [];
                this.fileListChange.emit(this.fileList);
            });
        }
    }
    get showDownload() {
        return !!this.service.download;
    }
    /** Valida el tamanio antes de aceptar el archivo. */
    beforeUpload = (file) => {
        if (this.maxSizeKb > 0) {
            const sizeKb = (file.size ?? 0) / 1024;
            if (sizeKb > this.maxSizeKb) {
                return false;
            }
        }
        return true;
    };
    /** Delega la subida de cada archivo al servicio inyectado. */
    customRequest = (item) => {
        const file = item.postFile;
        return this.service.upload(file).subscribe({
            next: (res) => item.onSuccess?.(res ?? {}, item.file, res),
            error: (err) => item.onError?.(err, item.file),
        });
    };
    /** Descarga usando el servicio (si lo implementa). */
    onDownload = (file) => {
        if (!this.service.download) {
            return;
        }
        this.service.download(file).subscribe((blob) => {
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = file.name;
            link.click();
            window.URL.revokeObjectURL(url);
        });
    };
    /**
     * Elimina usando el servicio (si lo implementa).
     * Si el servicio no tiene `remove`, solo lo saca de la lista local.
     */
    onRemove = (file) => {
        if (!this.service.remove) {
            return true;
        }
        return this.service.remove(file).pipe(map(() => true));
    };
    /** Maneja los cambios de estado del upload (uploading | done | error | removed). */
    onChange(event) {
        this.fileList = event.fileList;
        this.fileListChange.emit(this.fileList);
        this.changed.emit(event);
        if (event.file.status === 'done') {
            this.uploaded.emit(event.file);
        }
        else if (event.file.status === 'removed') {
            this.removed.emit(event.file);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UploadFilesComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: UploadFilesComponent, isStandalone: true, selector: "app-upload-files", inputs: { service: "service", multiple: "multiple", accept: "accept", listType: "listType", maxSizeKb: "maxSizeKb", disabled: "disabled", buttonText: "buttonText", loadExisting: "loadExisting", fileList: "fileList" }, outputs: { fileListChange: "fileListChange", uploaded: "uploaded", removed: "removed", changed: "changed" }, providers: [
            provideNzIconsPatch([
                PaperClipOutline,
                DeleteOutline,
                DownloadOutline,
                LoadingOutline,
                UploadOutline,
                EyeOutline,
                PlusOutline,
            ]),
        ], ngImport: i0, template: "<nz-upload\n  [nzMultiple]=\"multiple\"\n  [nzAccept]=\"accept\"\n  [nzListType]=\"listType\"\n  [nzDisabled]=\"disabled\"\n  [nzFileList]=\"fileList\"\n  [nzCustomRequest]=\"customRequest\"\n  [nzBeforeUpload]=\"beforeUpload\"\n  [nzRemove]=\"onRemove\"\n  [nzDownload]=\"onDownload\"\n  [nzShowUploadList]=\"{\n    showRemoveIcon: true,\n    showDownloadIcon: showDownload,\n    showPreviewIcon: false,\n  }\"\n  (nzChange)=\"onChange($event)\"\n>\n  @if (listType === 'picture-card') {\n    <div>\n      <nz-icon nzType=\"plus\"></nz-icon>\n      <div class=\"ant-upload-text\">{{ buttonText }}</div>\n    </div>\n  } @else {\n    <button nz-button type=\"button\" [disabled]=\"disabled\">\n      <nz-icon nzType=\"upload\"></nz-icon>\n      {{ buttonText }}\n    </button>\n  }\n</nz-upload>\n", dependencies: [{ kind: "ngmodule", type: NzUploadModule }, { kind: "component", type: i1$6.NzUploadComponent, selector: "nz-upload", inputs: ["nzId", "nzType", "nzLimit", "nzSize", "nzFileType", "nzAccept", "nzAction", "nzDirectory", "nzOpenFileDialogOnClick", "nzBeforeUpload", "nzCustomRequest", "nzData", "nzFilter", "nzFileList", "nzDisabled", "nzHeaders", "nzListType", "nzMultiple", "nzName", "nzShowUploadList", "nzShowButton", "nzWithCredentials", "nzRemove", "nzPreview", "nzPreviewFile", "nzPreviewIsImage", "nzTransformFile", "nzDownload", "nzIconRender", "nzFileListRender", "nzMaxCount"], outputs: ["nzChange", "nzFileListChange"], exportAs: ["nzUpload"] }, { kind: "ngmodule", type: NzButtonModule }, { kind: "component", type: i2$1.NzButtonComponent, selector: "button[nz-button], a[nz-button]", inputs: ["nzBlock", "nzGhost", "nzSearch", "nzLoading", "nzDanger", "disabled", "tabIndex", "nzType", "nzShape", "nzSize"], exportAs: ["nzButton"] }, { kind: "directive", type: i3.ɵNzTransitionPatchDirective, selector: "[nz-button], [nz-icon], nz-icon, [nz-menu-item], [nz-submenu], nz-select-top-control, nz-select-placeholder, nz-input-group", inputs: ["hidden"] }, { kind: "directive", type: i4$1.NzWaveDirective, selector: "[nz-wave],button[nz-button]:not([nzType=\"link\"]):not([nzType=\"text\"])", inputs: ["nzWaveExtraNode"], exportAs: ["nzWave"] }, { kind: "ngmodule", type: NzIconModule }, { kind: "directive", type: i3$2.NzIconDirective, selector: "nz-icon,[nz-icon]", inputs: ["nzSpin", "nzRotate", "nzType", "nzTheme", "nzTwotoneColor", "nzIconfont"], exportAs: ["nzIcon"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UploadFilesComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-upload-files', imports: [NzUploadModule, NzButtonModule, NzIconModule], providers: [
                        provideNzIconsPatch([
                            PaperClipOutline,
                            DeleteOutline,
                            DownloadOutline,
                            LoadingOutline,
                            UploadOutline,
                            EyeOutline,
                            PlusOutline,
                        ]),
                    ], template: "<nz-upload\n  [nzMultiple]=\"multiple\"\n  [nzAccept]=\"accept\"\n  [nzListType]=\"listType\"\n  [nzDisabled]=\"disabled\"\n  [nzFileList]=\"fileList\"\n  [nzCustomRequest]=\"customRequest\"\n  [nzBeforeUpload]=\"beforeUpload\"\n  [nzRemove]=\"onRemove\"\n  [nzDownload]=\"onDownload\"\n  [nzShowUploadList]=\"{\n    showRemoveIcon: true,\n    showDownloadIcon: showDownload,\n    showPreviewIcon: false,\n  }\"\n  (nzChange)=\"onChange($event)\"\n>\n  @if (listType === 'picture-card') {\n    <div>\n      <nz-icon nzType=\"plus\"></nz-icon>\n      <div class=\"ant-upload-text\">{{ buttonText }}</div>\n    </div>\n  } @else {\n    <button nz-button type=\"button\" [disabled]=\"disabled\">\n      <nz-icon nzType=\"upload\"></nz-icon>\n      {{ buttonText }}\n    </button>\n  }\n</nz-upload>\n" }]
        }], propDecorators: { service: [{
                type: Input,
                args: [{ required: true }]
            }], multiple: [{
                type: Input
            }], accept: [{
                type: Input
            }], listType: [{
                type: Input
            }], maxSizeKb: [{
                type: Input
            }], disabled: [{
                type: Input
            }], buttonText: [{
                type: Input
            }], loadExisting: [{
                type: Input
            }], fileList: [{
                type: Input
            }], fileListChange: [{
                type: Output
            }], uploaded: [{
                type: Output
            }], removed: [{
                type: Output
            }], changed: [{
                type: Output
            }] } });

/*
 * Public API Surface of lib-components
 */

/**
 * Generated bundle index. Do not edit.
 */

export { APP_DATE_FORMATS, AlertDialogComponent, AlertService, BaseGridService, BaseUploadService, BasicDialogComponent, BreadcrumbComponent, ButtonComponent, COMBO_DATA_PROVIDER, ComboComponent, CoreViewComponent, CuitMaskComponent, DashboardComponent, DashboardV2Component, DateFormFieldComponent, DecimalFormFieldComponent, DynamicFormatPipe, EditableGridService, FadeInComponent, FilterComponent, FormFieldComponent, GlobalSpinnerComponent, GridColumn, GridComponent, GridMenuAction, GridToolBarAction, ICONS, LocalGridService, MultipleComboComponent, NumberFormFieldComponent, SelectebleSettings, TextareaFormFieldComponent, UploadFilesComponent, ViajeMaskComponent, uuid };
//# sourceMappingURL=lib-components.mjs.map
