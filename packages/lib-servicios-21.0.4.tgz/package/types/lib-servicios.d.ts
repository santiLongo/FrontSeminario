import { HttpInterceptorFn, HttpClient } from '@angular/common/http';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { Type } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';

declare const apiResponseInterceptor: HttpInterceptorFn;

declare const authInterceptor: HttpInterceptorFn;

interface ApiResponse<T> {
    data: T;
    ok: boolean;
    hayErrores: boolean;
    error: string | null;
    errores: string[];
    isSessionAlive: boolean;
}
interface HttpRef {
    loading: boolean;
}

interface PagedResult<T> {
    items: T[];
    total: number;
}
interface GridState {
    page: number;
    pageSize: number;
    sort?: {
        field: string;
        direction: 'asc' | 'desc';
    };
    filters?: Record<string, any>;
}

declare class LoadingService {
    private loadingSubject;
    private messageSubject;
    loading$: rxjs.Observable<boolean>;
    message$: rxjs.Observable<string>;
    show(message?: string): void;
    hide(): void;
    get isLoading(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoadingService>;
}

declare class ApiHttpService {
    private http;
    private loadingService;
    constructor(http: HttpClient, loadingService: LoadingService);
    private getHeaders;
    get<T>(url: string, params?: any, ref?: HttpRef): Observable<T>;
    getState<T>(url: string, params: any, state: GridState, ref?: HttpRef): Observable<PagedResult<T>>;
    downloadGet(url: string, fileName: string, params?: any, ref?: HttpRef): void;
    downloadGet$(url: string, fileName: string, params?: any, ref?: HttpRef): Observable<void>;
    getWithBlock<T>(url: string, params?: any, message?: string): Observable<T>;
    post<T>(url: string, body: any, ref?: HttpRef, extraParams?: any): Observable<T>;
    postWithBlock<T>(url: string, body: any, extraParams?: any, message?: string): Observable<T>;
    putWithBlock<T>(url: string, body: any, message?: string): Observable<T>;
    download(url: string, fileName: string, body?: any, ref?: HttpRef): void;
    download$(url: string, fileName: string, body?: any, ref?: HttpRef): Observable<void>;
    private buildParams;
    private setLoading;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApiHttpService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApiHttpService>;
}

declare class AuthService {
    private router;
    private TOKEN_KEY;
    constructor(router: Router);
    getToken(): string | null;
    isLogged(): boolean;
    logout(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthService>;
}

type DialogSize = 's' | 'm' | 'l' | 'xl' | 'xxl' | 'full';
declare class DialogService {
    private dialog;
    constructor(dialog: MatDialog);
    open<TComponent, TData = any, TResult = any>(component: Type<TComponent>, options?: {
        size?: DialogSize;
        data?: TData;
        config?: MatDialogConfig;
    }): MatDialogRef<TComponent, TResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DialogService>;
}

declare class ReponseDialogService {
    private dialog;
    constructor(dialog: MatDialog);
    showError(message: string, status?: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReponseDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReponseDialogService>;
}

type EventHandler<T = any, TResponse = any> = (payload: T) => TResponse | Observable<TResponse>;
interface ListenerToken {
    key: string;
    unregister(): void;
}
type DuplicatePolicy = 'throw' | 'replace' | 'ignore';
declare class EventBusService {
    private listeners;
    register<T = any, TResponse = any>(// ← ahora también lleva TResponse
    key: string, handler: EventHandler<T, TResponse>, onDuplicate?: DuplicatePolicy): ListenerToken;
    emit<T = any, TResponse = any>(key: string, payload?: T): TResponse | undefined;
    emit$<T = any, TResponse = any>(key: string, payload?: T): Observable<TResponse>;
    has(key: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventBusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventBusService>;
}

export { ApiHttpService, AuthService, DialogService, EventBusService, LoadingService, ReponseDialogService, apiResponseInterceptor, authInterceptor };
export type { ApiResponse, DialogSize, EventHandler, GridState, HttpRef, ListenerToken, PagedResult };
