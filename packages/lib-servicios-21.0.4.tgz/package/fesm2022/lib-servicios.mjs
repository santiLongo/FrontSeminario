import * as i0 from '@angular/core';
import { Inject, Component, Injectable, inject } from '@angular/core';
import * as i1$2 from '@angular/common/http';
import { HttpResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { map, catchError, throwError, BehaviorSubject, finalize, switchMap, of, EMPTY, isObservable } from 'rxjs';
import * as i1$1 from '@angular/router';
import { Router } from '@angular/router';
import * as i1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i2 from 'ng-zorro-antd/button';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import * as i5 from 'ng-zorro-antd/result';
import { NzResultModule } from 'ng-zorro-antd/result';
import { NzTypographyModule } from 'ng-zorro-antd/typography';
import * as i3 from 'ng-zorro-antd/core/transition-patch';
import * as i4 from 'ng-zorro-antd/core/wave';
import { catchError as catchError$1 } from 'rxjs/operators';

class ShowErrorDialogComponent {
    dialogRef;
    type;
    error = '';
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.error = data.error;
        switch (data.status) {
            case 404:
                this.type = '404';
                break;
            case 401:
            case 403:
                this.type = '403';
                break;
            default:
                this.type = '500';
                break;
        }
    }
    onSalir() {
        this.dialogRef.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ShowErrorDialogComponent, deps: [{ token: i1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ShowErrorDialogComponent, isStandalone: true, selector: "app-show-error-dialog", ngImport: i0, template: "<nz-result\n  nzTitle=\"Ocurrio un error\"\n  [nzStatus]=\"type\"\n  [nzSubTitle]=\"error\"\n>\n  <div nz-result-extra>\n    <button nz-button nzType=\"primary\" (click)=\"onSalir()\">Salir</button>\n  </div>\n</nz-result>\n", dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: NzButtonModule }, { kind: "component", type: i2.NzButtonComponent, selector: "button[nz-button], a[nz-button]", inputs: ["nzBlock", "nzGhost", "nzSearch", "nzLoading", "nzDanger", "disabled", "tabIndex", "nzType", "nzShape", "nzSize"], exportAs: ["nzButton"] }, { kind: "directive", type: i3.ɵNzTransitionPatchDirective, selector: "[nz-button], [nz-icon], nz-icon, [nz-menu-item], [nz-submenu], nz-select-top-control, nz-select-placeholder, nz-input-group", inputs: ["hidden"] }, { kind: "directive", type: i4.NzWaveDirective, selector: "[nz-wave],button[nz-button]:not([nzType=\"link\"]):not([nzType=\"text\"])", inputs: ["nzWaveExtraNode"], exportAs: ["nzWave"] }, { kind: "ngmodule", type: NzResultModule }, { kind: "component", type: i5.NzResultComponent, selector: "nz-result", inputs: ["nzIcon", "nzTitle", "nzSubTitle", "nzExtra", "nzStatus"], exportAs: ["nzResult"] }, { kind: "directive", type: i5.NzResultExtraDirective, selector: "div[nz-result-extra]", exportAs: ["nzResultExtra"] }, { kind: "ngmodule", type: NzTypographyModule }, { kind: "ngmodule", type: NzIconModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ShowErrorDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-show-error-dialog', imports: [MatDialogModule, NzButtonModule, NzResultModule, NzTypographyModule, NzIconModule], template: "<nz-result\n  nzTitle=\"Ocurrio un error\"\n  [nzStatus]=\"type\"\n  [nzSubTitle]=\"error\"\n>\n  <div nz-result-extra>\n    <button nz-button nzType=\"primary\" (click)=\"onSalir()\">Salir</button>\n  </div>\n</nz-result>\n" }]
        }], ctorParameters: () => [{ type: i1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class ReponseDialogService {
    dialog;
    constructor(dialog) {
        this.dialog = dialog;
    }
    showError(message, status = 500) {
        this.dialog.open(ShowErrorDialogComponent, { data: { error: message, status: status }, width: '600px' });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ReponseDialogService, deps: [{ token: i1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ReponseDialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ReponseDialogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.MatDialog }] });

// api-response.interceptor.ts
const apiResponseInterceptor = (req, next) => {
    const dialogService = inject(ReponseDialogService);
    const router = inject(Router);
    return next(req).pipe(map((event) => {
        if (event instanceof HttpResponse && event.body?.ok !== undefined) {
            const response = event.body;
            if (!response.ok || response.hayErrores) {
                const message = response.error ||
                    response.errores?.join('\n') ||
                    'Ocurrió un error';
                dialogService.showError(message);
                throw new Error(message);
            }
            if (!response.isSessionAlive) {
                dialogService.showError('Sesión expirada');
                localStorage.clear();
                router.navigate(['/login']);
                throw new Error('Session expired');
            }
            return event.clone({
                body: response.data
            });
        }
        return event;
    }), catchError((error) => {
        let message = error.error?.message ||
            error.message ||
            'Error inesperado del servidor';
        if (error.error?.message == undefined)
            message = 'Error al comunicarse con el servidor';
        if (error.status === 401) {
            message = "Sesion expirada";
            localStorage.clear();
        }
        dialogService.showError(message, error.status);
        return throwError(() => error);
    }));
};

class AuthService {
    router;
    TOKEN_KEY = 'token';
    constructor(router) {
        this.router = router;
    }
    getToken() {
        return localStorage.getItem(this.TOKEN_KEY);
    }
    isLogged() {
        return !!this.getToken();
    }
    logout() {
        localStorage.removeItem(this.TOKEN_KEY);
        this.router.navigate(['/login']);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AuthService, deps: [{ token: i1$1.Router }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AuthService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AuthService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.Router }] });

// auth.interceptor.ts
const authInterceptor = (req, next) => {
    const authService = inject(AuthService);
    const router = inject(Router);
    const token = authService.getToken();
    if (!token) {
        router.navigate(['/login']);
        return next(req);
    }
    const authReq = req.clone({
        setHeaders: {
            Authorization: `Bearer ${token}`
        }
    });
    return next(authReq).pipe(catchError$1((error) => {
        if (error.status === 401 || error.status === 403) {
            // authService.logout();
        }
        return throwError(() => error);
    }));
};

class LoadingService {
    loadingSubject = new BehaviorSubject(false);
    messageSubject = new BehaviorSubject('Cargando...');
    loading$ = this.loadingSubject.asObservable();
    message$ = this.messageSubject.asObservable();
    show(message = 'Cargando...') {
        this.messageSubject.next(message);
        this.loadingSubject.next(true);
    }
    hide() {
        this.loadingSubject.next(false);
        this.messageSubject.next('Cargando...');
    }
    get isLoading() {
        return this.loadingSubject.value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LoadingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LoadingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class ApiHttpService {
    http;
    loadingService;
    constructor(http, loadingService) {
        this.http = http;
        this.loadingService = loadingService;
    }
    getHeaders() {
        const token = localStorage.getItem('token');
        return new HttpHeaders({
            Authorization: token ? `Bearer ${token}` : '',
        });
    }
    get(url, params, ref) {
        return this.http.get(url, {
            headers: this.getHeaders(),
            params: this.buildParams(params),
        });
    }
    getState(url, params, state, ref) {
        this.setLoading(ref, true);
        let finalParams = {
            ...params,
            page: state.page,
            pageSize: state.pageSize,
        };
        if (state.sort) {
            finalParams['sort.field'] = state.sort.field;
            finalParams['sort.direction'] = state.sort.direction;
        }
        if (state.filters) {
            Object.entries(state.filters).forEach(([key, value]) => {
                if (value !== null && value !== undefined && value !== '') {
                    finalParams[`filters[${key}]`] = value;
                }
            });
        }
        const httpParams = this.buildParams(finalParams);
        return this.http
            .get(url, {
            headers: this.getHeaders(),
            params: httpParams,
        })
            .pipe(finalize(() => this.setLoading(ref, false)));
    }
    downloadGet(url, fileName, params, ref) {
        this.setLoading(ref, true);
        this.http
            .get(url, {
            headers: this.getHeaders(),
            params: this.buildParams(params),
            responseType: 'blob',
        })
            .pipe(finalize(() => this.setLoading(ref, false)))
            .subscribe((blob) => {
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = fileName;
            link.click();
            window.URL.revokeObjectURL(url);
        });
    }
    downloadGet$(url, fileName, params, ref) {
        this.setLoading(ref, true);
        return this.http
            .get(url, {
            headers: this.getHeaders(),
            params: this.buildParams(params),
            responseType: 'blob',
        })
            .pipe(finalize(() => this.setLoading(ref, false)), switchMap((blob) => {
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = fileName;
            link.click();
            window.URL.revokeObjectURL(url);
            return of();
        }));
    }
    getWithBlock(url, params, message) {
        this.loadingService.show(message);
        return this.http
            .get(url, {
            headers: this.getHeaders(),
            params: this.buildParams(params),
        })
            .pipe(finalize(() => this.loadingService.hide()));
    }
    post(url, body, ref, extraParams) {
        this.setLoading(ref, true);
        return this.http
            .post(url, body, {
            headers: this.getHeaders(),
            params: this.buildParams(extraParams),
        })
            .pipe(finalize(() => this.setLoading(ref, false)));
    }
    postWithBlock(url, body, extraParams, message) {
        this.loadingService.show(message);
        return this.http
            .post(url, body, {
            headers: this.getHeaders(),
            params: this.buildParams(extraParams),
        })
            .pipe(finalize(() => this.loadingService.hide()));
    }
    putWithBlock(url, body, message) {
        this.loadingService.show(message);
        return this.http
            .put(url, body, {
            headers: this.getHeaders(),
        })
            .pipe(finalize(() => this.loadingService.hide()));
    }
    download(url, fileName, body, ref) {
        this.setLoading(ref, true);
        this.http
            .post(url, {
            headers: this.getHeaders(),
            params: this.buildParams(body),
            ref,
        })
            .pipe(finalize(() => this.setLoading(ref, false)))
            .subscribe((blob) => {
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = fileName;
            link.click();
            window.URL.revokeObjectURL(url);
        });
    }
    download$(url, fileName, body, ref) {
        this.setLoading(ref, true);
        return this.http
            .post(url, {
            headers: this.getHeaders(),
            params: this.buildParams(body),
            ref,
        })
            .pipe(finalize(() => this.setLoading(ref, false)), switchMap((blob) => {
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = fileName;
            link.click();
            window.URL.revokeObjectURL(url);
            return of();
        }));
    }
    buildParams(params) {
        let httpParams = new HttpParams();
        if (!params || typeof params !== 'object') {
            return httpParams;
        }
        Object.entries(params).forEach(([key, value]) => {
            if (value === null || value === undefined) {
                return;
            }
            if (Array.isArray(value)) {
                value.forEach((v) => {
                    if (v !== null && v !== undefined) {
                        httpParams = httpParams.append(key, String(v));
                    }
                });
                return;
            }
            if (value instanceof Date) {
                httpParams = httpParams.set(key, value.toISOString());
                return;
            }
            if (typeof value !== 'object') {
                httpParams = httpParams.set(key, String(value));
            }
        });
        return httpParams;
    }
    setLoading(ref, loading) {
        if (ref) {
            ref.loading = loading;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApiHttpService, deps: [{ token: i1$2.HttpClient }, { token: LoadingService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApiHttpService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApiHttpService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$2.HttpClient }, { type: LoadingService }] });

const SIZE_MAP = {
    s: {
        width: '400px',
    },
    m: {
        width: '600px',
    },
    l: {
        width: '800px',
    },
    xl: {
        width: '1000px',
    },
    xxl: {
        width: '1200px',
    },
    full: {
        width: '100vw',
        height: '100vh',
        maxWidth: '100vw',
        maxHeight: '100vh',
        panelClass: 'dialog-fullscreen'
    }
};
class DialogService {
    dialog;
    constructor(dialog) {
        this.dialog = dialog;
    }
    open(component, options) {
        const baseSize = SIZE_MAP[options?.size ?? 'm'];
        const config = {
            ...baseSize,
            maxWidth: 'none',
            maxHeight: 'none',
            autoFocus: false,
            restoreFocus: false,
            data: options?.data,
            ...options?.config,
        };
        return this.dialog.open(component, config);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DialogService, deps: [{ token: i1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DialogService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.MatDialog }] });

class EventBusService {
    listeners = new Map();
    register(// ← ahora también lleva TResponse
    key, handler, onDuplicate = 'throw') {
        if (this.listeners.has(key)) {
            switch (onDuplicate) {
                case 'throw':
                    throw new Error(`[EventBus] Ya hay un oyente con la clave "${key}"`);
                case 'ignore':
                    return { key, unregister: () => { } };
                case 'replace':
                    break;
            }
        }
        this.listeners.set(key, handler);
        return {
            key,
            unregister: () => {
                if (this.listeners.get(key) === handler) {
                    this.listeners.delete(key);
                }
            },
        };
    }
    // sincrónico: usalo SOLO para handlers sincrónicos
    emit(key, payload) {
        const handler = this.listeners.get(key);
        if (!handler) {
            console.warn(`[EventBus] No hay oyente para "${key}"`);
            return undefined;
        }
        return handler(payload);
    }
    // aplana: si el handler ya devuelve Observable, lo pasa tal cual
    emit$(key, payload) {
        const handler = this.listeners.get(key);
        if (!handler) {
            console.warn(`[EventBus] No hay oyente para "${key}"`);
            return EMPTY;
        }
        const result = handler(payload);
        return isObservable(result) ? result : of(result);
    }
    has(key) {
        return this.listeners.has(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EventBusService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EventBusService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EventBusService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Public API Surface of lib-servicios
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiHttpService, AuthService, DialogService, EventBusService, LoadingService, ReponseDialogService, apiResponseInterceptor, authInterceptor };
//# sourceMappingURL=lib-servicios.mjs.map
