import * as i0 from '@angular/core';
import { Inject, Component, Injectable, inject } from '@angular/core';
import * as i1$2 from '@angular/common/http';
import { HttpResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { map, catchError, throwError, BehaviorSubject, finalize, tap, switchMap, of, EMPTY, isObservable } from 'rxjs';
import * as i1$1 from '@angular/router';
import { Router } from '@angular/router';
import * as i1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i2 from 'ng-zorro-antd/button';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import * as i5 from 'ng-zorro-antd/result';
import { NzResultModule } from 'ng-zorro-antd/result';
import { NzTypographyModule } from 'ng-zorro-antd/typography';
import * as i3 from 'ng-zorro-antd/core/transition-patch';
import * as i4 from 'ng-zorro-antd/core/wave';
import { catchError as catchError$1 } from 'rxjs/operators';
import { MatIcon } from '@angular/material/icon';
import * as i2$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';

class ShowErrorDialogComponent {
    dialogRef;
    type;
    error = '';
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.error = data.error;
        switch (data.status) {
            case 404:
                this.type = '404';
                break;
            case 401:
            case 403:
                this.type = '403';
                break;
            default:
                this.type = '500';
                break;
        }
    }
    onSalir() {
        this.dialogRef.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ShowErrorDialogComponent, deps: [{ token: i1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ShowErrorDialogComponent, isStandalone: true, selector: "app-show-error-dialog", ngImport: i0, template: "<nz-result\n  nzTitle=\"Ocurrio un error\"\n  [nzStatus]=\"type\"\n  [nzSubTitle]=\"error\"\n>\n  <div nz-result-extra>\n    <button nz-button nzType=\"primary\" (click)=\"onSalir()\">Salir</button>\n  </div>\n</nz-result>\n", dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: NzButtonModule }, { kind: "component", type: i2.NzButtonComponent, selector: "button[nz-button], a[nz-button]", inputs: ["nzBlock", "nzGhost", "nzSearch", "nzLoading", "nzDanger", "disabled", "tabIndex", "nzType", "nzShape", "nzSize"], exportAs: ["nzButton"] }, { kind: "directive", type: i3.ɵNzTransitionPatchDirective, selector: "[nz-button], [nz-icon], nz-icon, [nz-menu-item], [nz-submenu], nz-select-top-control, nz-select-placeholder, nz-input-group", inputs: ["hidden"] }, { kind: "directive", type: i4.NzWaveDirective, selector: "[nz-wave],button[nz-button]:not([nzType=\"link\"]):not([nzType=\"text\"])", inputs: ["nzWaveExtraNode"], exportAs: ["nzWave"] }, { kind: "ngmodule", type: NzResultModule }, { kind: "component", type: i5.NzResultComponent, selector: "nz-result", inputs: ["nzIcon", "nzTitle", "nzSubTitle", "nzExtra", "nzStatus"], exportAs: ["nzResult"] }, { kind: "directive", type: i5.NzResultExtraDirective, selector: "div[nz-result-extra]", exportAs: ["nzResultExtra"] }, { kind: "ngmodule", type: NzTypographyModule }, { kind: "ngmodule", type: NzIconModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ShowErrorDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-show-error-dialog', imports: [MatDialogModule, NzButtonModule, NzResultModule, NzTypographyModule, NzIconModule], template: "<nz-result\n  nzTitle=\"Ocurrio un error\"\n  [nzStatus]=\"type\"\n  [nzSubTitle]=\"error\"\n>\n  <div nz-result-extra>\n    <button nz-button nzType=\"primary\" (click)=\"onSalir()\">Salir</button>\n  </div>\n</nz-result>\n" }]
        }], ctorParameters: () => [{ type: i1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class ReponseDialogService {
    dialog;
    constructor(dialog) {
        this.dialog = dialog;
    }
    showError(message, status = 500) {
        this.dialog.open(ShowErrorDialogComponent, { data: { error: message, status: status }, width: '600px' });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ReponseDialogService, deps: [{ token: i1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ReponseDialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ReponseDialogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.MatDialog }] });

// api-response.interceptor.ts
const apiResponseInterceptor = (req, next) => {
    const dialogService = inject(ReponseDialogService);
    const router = inject(Router);
    return next(req).pipe(map((event) => {
        if (event instanceof HttpResponse && event.body?.ok !== undefined) {
            const response = event.body;
            if (!response.ok || response.hayErrores) {
                const message = response.error ||
                    response.errores?.join('\n') ||
                    'Ocurrió un error';
                dialogService.showError(message);
                throw new Error(message);
            }
            if (!response.isSessionAlive) {
                dialogService.showError('Sesión expirada');
                localStorage.clear();
                router.navigate(['/login']);
                throw new Error('Session expired');
            }
            return event.clone({
                body: response.data
            });
        }
        return event;
    }), catchError((error) => {
        let message = error.error?.message ||
            error.message ||
            'Error inesperado del servidor';
        if (error.error?.message == undefined)
            message = 'Error al comunicarse con el servidor';
        if (error.status === 401) {
            message = "Sesion expirada";
            localStorage.clear();
        }
        dialogService.showError(message, error.status);
        return throwError(() => error);
    }));
};

class AuthService {
    router;
    TOKEN_KEY = 'token';
    constructor(router) {
        this.router = router;
    }
    getToken() {
        return localStorage.getItem(this.TOKEN_KEY);
    }
    isLogged() {
        return !!this.getToken();
    }
    logout() {
        localStorage.removeItem(this.TOKEN_KEY);
        this.router.navigate(['/login']);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AuthService, deps: [{ token: i1$1.Router }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AuthService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AuthService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.Router }] });

// auth.interceptor.ts
const authInterceptor = (req, next) => {
    const authService = inject(AuthService);
    const router = inject(Router);
    const token = authService.getToken();
    if (!token) {
        router.navigate(['/login']);
        return next(req);
    }
    const authReq = req.clone({
        setHeaders: {
            Authorization: `Bearer ${token}`
        }
    });
    return next(authReq).pipe(catchError$1((error) => {
        if (error.status === 401 || error.status === 403) {
            // authService.logout();
        }
        return throwError(() => error);
    }));
};

class ApiNovedades {
    errores;
    advertencias;
    oks;
    cantidadErrores() {
        return this.errores.length;
    }
    cantidadAdvertencias() {
        return this.advertencias.length;
    }
    cantidadOks() {
        return this.oks.length;
    }
    tengoNovedades() {
        return (this.cantidadAdvertencias() > 0 ||
            this.cantidadErrores() > 0 ||
            this.cantidadOks() > 0);
    }
}
class ApiNovedadesResponse extends ApiNovedades {
    data;
}

class LoadingService {
    loadingSubject = new BehaviorSubject(false);
    messageSubject = new BehaviorSubject('Cargando...');
    loading$ = this.loadingSubject.asObservable();
    message$ = this.messageSubject.asObservable();
    show(message = 'Cargando...') {
        this.messageSubject.next(message);
        this.loadingSubject.next(true);
    }
    hide() {
        this.loadingSubject.next(false);
        this.messageSubject.next('Cargando...');
    }
    get isLoading() {
        return this.loadingSubject.value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LoadingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LoadingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LoadingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class NovedadesDialogComponent {
    dialogRef;
    data;
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
    }
    cerrar() {
        this.dialogRef.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NovedadesDialogComponent, deps: [{ token: i1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.19", type: NovedadesDialogComponent, isStandalone: true, selector: "app-novedades-dialog", ngImport: i0, template: "<h2 mat-dialog-title>\n  Resultado de la operaci\u00F3n\n</h2>\n\n<mat-dialog-content>\n\n  <!-- OKS -->\n  @if (data.cantidadOks() > 0) {\n    <section class=\"novedad-section ok-section\">\n\n      <div class=\"section-header\">\n        <div class=\"icon-container\">\n          <mat-icon>check</mat-icon>\n        </div>\n\n        <div>\n          <h3>Operaci\u00F3n exitosa</h3>\n          <span>\n            {{ data.cantidadOks() }}\n            {{ data.cantidadOks() === 1 ? 'operaci\u00F3n realizada' : 'operaciones realizadas' }}\n          </span>\n        </div>\n      </div>\n\n      <ul>\n        @for (ok of data.oks; track $index) {\n          <li>{{ ok }}</li>\n        }\n      </ul>\n\n    </section>\n  }\n\n\n  <!-- ADVERTENCIAS -->\n  @if (data.cantidadAdvertencias() > 0) {\n    <section class=\"novedad-section warning-section\">\n\n      <div class=\"section-header\">\n        <div class=\"icon-container\">\n          <mat-icon>warning</mat-icon>\n        </div>\n\n        <div>\n          <h3>Advertencias</h3>\n          <span>\n            {{ data.cantidadAdvertencias() }}\n            {{ data.cantidadAdvertencias() === 1 ? 'advertencia' : 'advertencias' }}\n          </span>\n        </div>\n      </div>\n\n      <ul>\n        @for (advertencia of data.advertencias; track $index) {\n          <li>{{ advertencia }}</li>\n        }\n      </ul>\n\n    </section>\n  }\n\n\n  <!-- ERRORES -->\n  @if (data.cantidadErrores() > 0) {\n    <section class=\"novedad-section error-section\">\n\n      <div class=\"section-header\">\n        <div class=\"icon-container\">\n          <mat-icon>close</mat-icon>\n        </div>\n\n        <div>\n          <h3>Errores</h3>\n          <span>\n            {{ data.cantidadErrores() }}\n            {{ data.cantidadErrores() === 1 ? 'error encontrado' : 'errores encontrados' }}\n          </span>\n        </div>\n      </div>\n\n      <ul>\n        @for (error of data.errores; track $index) {\n          <li>{{ error }}</li>\n        }\n      </ul>\n\n    </section>\n  }\n\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-flat-button (click)=\"cerrar()\">\n    Cerrar\n  </button>\n</mat-dialog-actions>", styles: [":host{display:block}mat-dialog-content{min-width:500px;max-width:700px;padding-top:8px}.novedad-section{border-radius:12px;padding:16px;margin-bottom:14px;border:1px solid}.section-header{display:flex;align-items:center;gap:12px}.icon-container{width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}.icon-container mat-icon{font-size:22px;width:22px;height:22px}h3{margin:0;font-size:16px;font-weight:600}span{font-size:13px;opacity:.75}ul{margin:14px 0 0 50px;padding:0}li{margin-bottom:7px;line-height:1.4}li:last-child{margin-bottom:0}.ok-section{border-color:#b7dfc2;background:#f1faf3}.ok-section .icon-container{background:#d5f2dc;color:#218838}.ok-section h3{color:#1e7e34}.warning-section{border-color:#ffe08a;background:#fffaf0}.warning-section .icon-container{background:#fff0bd;color:#b77900}.warning-section h3{color:#9a6700}.error-section{border-color:#f1b8b8;background:#fff5f5}.error-section .icon-container{background:#f8d7da;color:#c82333}.error-section h3{color:#bd2130}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2$1.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NovedadesDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'app-novedades-dialog', imports: [MatDialogModule, MatIcon, MatButtonModule], template: "<h2 mat-dialog-title>\n  Resultado de la operaci\u00F3n\n</h2>\n\n<mat-dialog-content>\n\n  <!-- OKS -->\n  @if (data.cantidadOks() > 0) {\n    <section class=\"novedad-section ok-section\">\n\n      <div class=\"section-header\">\n        <div class=\"icon-container\">\n          <mat-icon>check</mat-icon>\n        </div>\n\n        <div>\n          <h3>Operaci\u00F3n exitosa</h3>\n          <span>\n            {{ data.cantidadOks() }}\n            {{ data.cantidadOks() === 1 ? 'operaci\u00F3n realizada' : 'operaciones realizadas' }}\n          </span>\n        </div>\n      </div>\n\n      <ul>\n        @for (ok of data.oks; track $index) {\n          <li>{{ ok }}</li>\n        }\n      </ul>\n\n    </section>\n  }\n\n\n  <!-- ADVERTENCIAS -->\n  @if (data.cantidadAdvertencias() > 0) {\n    <section class=\"novedad-section warning-section\">\n\n      <div class=\"section-header\">\n        <div class=\"icon-container\">\n          <mat-icon>warning</mat-icon>\n        </div>\n\n        <div>\n          <h3>Advertencias</h3>\n          <span>\n            {{ data.cantidadAdvertencias() }}\n            {{ data.cantidadAdvertencias() === 1 ? 'advertencia' : 'advertencias' }}\n          </span>\n        </div>\n      </div>\n\n      <ul>\n        @for (advertencia of data.advertencias; track $index) {\n          <li>{{ advertencia }}</li>\n        }\n      </ul>\n\n    </section>\n  }\n\n\n  <!-- ERRORES -->\n  @if (data.cantidadErrores() > 0) {\n    <section class=\"novedad-section error-section\">\n\n      <div class=\"section-header\">\n        <div class=\"icon-container\">\n          <mat-icon>close</mat-icon>\n        </div>\n\n        <div>\n          <h3>Errores</h3>\n          <span>\n            {{ data.cantidadErrores() }}\n            {{ data.cantidadErrores() === 1 ? 'error encontrado' : 'errores encontrados' }}\n          </span>\n        </div>\n      </div>\n\n      <ul>\n        @for (error of data.errores; track $index) {\n          <li>{{ error }}</li>\n        }\n      </ul>\n\n    </section>\n  }\n\n</mat-dialog-content>\n\n<mat-dialog-actions align=\"end\">\n  <button mat-flat-button (click)=\"cerrar()\">\n    Cerrar\n  </button>\n</mat-dialog-actions>", styles: [":host{display:block}mat-dialog-content{min-width:500px;max-width:700px;padding-top:8px}.novedad-section{border-radius:12px;padding:16px;margin-bottom:14px;border:1px solid}.section-header{display:flex;align-items:center;gap:12px}.icon-container{width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}.icon-container mat-icon{font-size:22px;width:22px;height:22px}h3{margin:0;font-size:16px;font-weight:600}span{font-size:13px;opacity:.75}ul{margin:14px 0 0 50px;padding:0}li{margin-bottom:7px;line-height:1.4}li:last-child{margin-bottom:0}.ok-section{border-color:#b7dfc2;background:#f1faf3}.ok-section .icon-container{background:#d5f2dc;color:#218838}.ok-section h3{color:#1e7e34}.warning-section{border-color:#ffe08a;background:#fffaf0}.warning-section .icon-container{background:#fff0bd;color:#b77900}.warning-section h3{color:#9a6700}.error-section{border-color:#f1b8b8;background:#fff5f5}.error-section .icon-container{background:#f8d7da;color:#c82333}.error-section h3{color:#bd2130}\n"] }]
        }], ctorParameters: () => [{ type: i1.MatDialogRef }, { type: ApiNovedades, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

const SIZE_MAP = {
    s: {
        width: '400px',
    },
    m: {
        width: '600px',
    },
    l: {
        width: '800px',
    },
    xl: {
        width: '1000px',
    },
    xxl: {
        width: '1200px',
    },
    full: {
        width: '100vw',
        height: '100vh',
        maxWidth: '100vw',
        maxHeight: '100vh',
        panelClass: 'dialog-fullscreen'
    }
};
class DialogService {
    dialog;
    constructor(dialog) {
        this.dialog = dialog;
    }
    open(component, options) {
        const baseSize = SIZE_MAP[options?.size ?? 'm'];
        const config = {
            ...baseSize,
            maxWidth: 'none',
            maxHeight: 'none',
            autoFocus: false,
            restoreFocus: false,
            data: options?.data,
            ...options?.config,
        };
        return this.dialog.open(component, config);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DialogService, deps: [{ token: i1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DialogService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.MatDialog }] });

class NovedadesDialogService {
    dialog;
    constructor(dialog) {
        this.dialog = dialog;
    }
    openNovedades$(novedades) {
        return this.dialog.open(NovedadesDialogComponent, {
            data: novedades
        }).afterClosed();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NovedadesDialogService, deps: [{ token: DialogService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NovedadesDialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NovedadesDialogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: DialogService }] });

class ApiHttpService {
    http;
    loadingService;
    novedadesService;
    constructor(http, loadingService, novedadesService) {
        this.http = http;
        this.loadingService = loadingService;
        this.novedadesService = novedadesService;
    }
    getHeaders() {
        const token = localStorage.getItem('token');
        return new HttpHeaders({
            Authorization: token ? `Bearer ${token}` : '',
        });
    }
    get(url, params, ref) {
        return this.http.get(url, {
            headers: this.getHeaders(),
            params: this.buildParams(params),
        });
    }
    getState(url, params, state, ref) {
        this.setLoading(ref, true);
        let finalParams = {
            ...params,
            page: state.page,
            pageSize: state.pageSize,
        };
        if (state.sort) {
            finalParams['sort.field'] = state.sort.field;
            finalParams['sort.direction'] = state.sort.direction;
        }
        if (state.filters) {
            Object.entries(state.filters).forEach(([key, value]) => {
                if (value !== null && value !== undefined && value !== '') {
                    finalParams[`filters[${key}]`] = value;
                }
            });
        }
        const httpParams = this.buildParams(finalParams);
        return this.http
            .get(url, {
            headers: this.getHeaders(),
            params: httpParams,
        })
            .pipe(finalize(() => this.setLoading(ref, false)));
    }
    downloadGet(url, fileName, params, ref) {
        this.setLoading(ref, true);
        this.http
            .get(url, {
            headers: this.getHeaders(),
            params: this.buildParams(params),
            responseType: 'blob',
        })
            .pipe(finalize(() => this.setLoading(ref, false)))
            .subscribe((blob) => {
            this.downloadFile(blob, fileName);
        });
    }
    downloadGet$(url, fileName, params, ref) {
        this.setLoading(ref, true);
        return this.http
            .get(url, {
            headers: this.getHeaders(),
            params: this.buildParams(params),
            responseType: 'blob',
        })
            .pipe(tap((blob) => this.downloadFile(blob, fileName)), finalize(() => this.setLoading(ref, false)), map(() => void 0));
    }
    getWithBlock(url, params, message) {
        this.loadingService.show(message);
        return this.http
            .get(url, {
            headers: this.getHeaders(),
            params: this.buildParams(params),
        })
            .pipe(finalize(() => this.loadingService.hide()));
    }
    post(url, body, ref, extraParams) {
        this.setLoading(ref, true);
        const obs$ = extraParams?.useNovedades
            ? this.http
                .post(url, body, {
                headers: this.getHeaders(),
                params: this.buildParams(extraParams?.queryParams),
            })
                .pipe(map(res => ApiHttpService.from(res)), switchMap((res) => {
                if (!res.tengoNovedades()) {
                    return of(res.data);
                }
                return this.novedadesService.openNovedades$(res).pipe(switchMap(() => of(res.data)));
            }))
            : this.http.post(url, body, {
                headers: this.getHeaders(),
                params: this.buildParams(extraParams?.queryParams),
            });
        return obs$.pipe(finalize(() => this.setLoading(ref, false)));
    }
    postWithBlock(url, body, extraParams, message) {
        this.loadingService.show(message);
        return this.post(url, body, undefined, extraParams).pipe(finalize(() => this.loadingService.hide()));
    }
    putWithBlock(url, body, message) {
        this.loadingService.show(message);
        return this.http
            .put(url, body, {
            headers: this.getHeaders(),
        })
            .pipe(finalize(() => this.loadingService.hide()));
    }
    download(url, fileName, body, ref) {
        this.setLoading(ref, true);
        this.http
            .post(url, {
            headers: this.getHeaders(),
            params: this.buildParams(body),
            ref,
        })
            .pipe(finalize(() => this.setLoading(ref, false)))
            .subscribe((blob) => {
            this.downloadFile(blob, fileName);
        });
    }
    download$(url, fileName, body, ref) {
        this.setLoading(ref, true);
        return this.http
            .post(url, {
            headers: this.getHeaders(),
            params: this.buildParams(body),
            ref,
        })
            .pipe(tap((blob) => this.downloadFile(blob, fileName)), finalize(() => this.setLoading(ref, false)), map(() => void 0));
    }
    buildParams(params) {
        let httpParams = new HttpParams();
        if (!params || typeof params !== 'object') {
            return httpParams;
        }
        Object.entries(params).forEach(([key, value]) => {
            if (value === null || value === undefined) {
                return;
            }
            if (Array.isArray(value)) {
                value.forEach((v) => {
                    if (v !== null && v !== undefined) {
                        httpParams = httpParams.append(key, String(v));
                    }
                });
                return;
            }
            if (value instanceof Date) {
                httpParams = httpParams.set(key, value.toISOString());
                return;
            }
            if (typeof value !== 'object') {
                httpParams = httpParams.set(key, String(value));
            }
        });
        return httpParams;
    }
    setLoading(ref, loading) {
        if (ref) {
            ref.loading = loading;
        }
    }
    downloadFile(blob, fileName) {
        const objectUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = objectUrl;
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => {
            URL.revokeObjectURL(objectUrl);
        }, 100);
    }
    static from(response) {
        return Object.assign(new ApiNovedadesResponse(), response);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApiHttpService, deps: [{ token: i1$2.HttpClient }, { token: LoadingService }, { token: NovedadesDialogService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApiHttpService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApiHttpService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$2.HttpClient }, { type: LoadingService }, { type: NovedadesDialogService }] });

class EventBusService {
    listeners = new Map();
    register(// ← ahora también lleva TResponse
    key, handler, onDuplicate = 'throw') {
        if (this.listeners.has(key)) {
            switch (onDuplicate) {
                case 'throw':
                    throw new Error(`[EventBus] Ya hay un oyente con la clave "${key}"`);
                case 'ignore':
                    return { key, unregister: () => { } };
                case 'replace':
                    break;
            }
        }
        this.listeners.set(key, handler);
        return {
            key,
            unregister: () => {
                if (this.listeners.get(key) === handler) {
                    this.listeners.delete(key);
                }
            },
        };
    }
    // sincrónico: usalo SOLO para handlers sincrónicos
    emit(key, payload) {
        const handler = this.listeners.get(key);
        if (!handler) {
            console.warn(`[EventBus] No hay oyente para "${key}"`);
            return undefined;
        }
        return handler(payload);
    }
    // aplana: si el handler ya devuelve Observable, lo pasa tal cual
    emit$(key, payload) {
        const handler = this.listeners.get(key);
        if (!handler) {
            console.warn(`[EventBus] No hay oyente para "${key}"`);
            return EMPTY;
        }
        const result = handler(payload);
        return isObservable(result) ? result : of(result);
    }
    has(key) {
        return this.listeners.has(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EventBusService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EventBusService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EventBusService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Public API Surface of lib-servicios
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApiHttpService, ApiNovedades, ApiNovedadesResponse, AuthService, DialogService, EventBusService, LoadingService, ReponseDialogService, apiResponseInterceptor, authInterceptor };
//# sourceMappingURL=lib-servicios.mjs.map
